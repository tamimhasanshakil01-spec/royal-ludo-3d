package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CardGiftcard
import androidx.compose.material.icons.outlined.Casino
import androidx.compose.material.icons.rounded.CardGiftcard
import androidx.compose.material.icons.rounded.Casino
import androidx.compose.material.icons.rounded.ManageAccounts
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.game.LudoUiState
import com.example.game.LudoViewModel
import com.example.game.PlayerColor
import com.example.ui.components.CelebrationParticleOverlay
import com.example.ui.components.NewGameSetupDialog
import com.example.ui.components.PlayerHudRow
import com.example.ui.components.PlayerIdentityDialog
import com.example.ui.components.ReferralRulesDialog
import com.example.ui.components.RoyalLudoBoard
import com.example.ui.components.RulesDialog
import com.example.ui.components.TurnControlBar
import com.example.ui.components.WinnerVictoryDialog
import com.example.ui.screens.InviteAndRulesScreen
import com.example.ui.theme.RoyalGold
import com.example.ui.theme.RoyalGoldTextOn
import com.example.ui.theme.RoyalLudoTheme
import com.example.ui.theme.RoyalNavyBorder
import com.example.ui.theme.RoyalNavyDeep
import com.example.ui.theme.RoyalNavyPanelBottom
import com.example.ui.theme.RoyalNavyPanelTop
import com.example.ui.theme.RoyalNavyPill
import com.example.ui.theme.RoyalNavyPillBorder
import com.example.ui.theme.RoyalNavySecondaryBtn
import com.example.ui.theme.RoyalNavyTop
import com.example.ui.theme.RoyalTextMuted
import com.example.ui.theme.RoyalTextPrimary
import com.example.ui.theme.RoyalTextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class AppTab {
    PLAY,
    INVITE
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            RoyalLudoTheme {
                RoyalLudoApp()
            }
        }
    }
}

@Composable
fun RoyalLudoApp(
    viewModel: LudoViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    var activeTab by rememberSaveable { mutableStateOf(AppTab.PLAY) }
    var showRulesDialog by rememberSaveable { mutableStateOf(false) }
    var showRefRulesDialog by rememberSaveable { mutableStateOf(false) }
    var showSetupDialog by rememberSaveable { mutableStateOf(false) }
    var editingIdentityPlayer by remember { mutableStateOf<PlayerColor?>(null) }
    var dismissedWinnerForMatch by rememberSaveable { mutableStateOf(false) }
    var showWinnerDialogReady by remember { mutableStateOf(false) }
    val profileSavedText = stringResource(R.string.profile_saved_snackbar)

    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(uiState.winner) {
        if (uiState.winner == null) {
            dismissedWinnerForMatch = false
            showWinnerDialogReady = false
        } else {
            showWinnerDialogReady = false
            delay(750L)
            showWinnerDialogReady = true
        }
    }

    if (activeTab != AppTab.PLAY) {
        BackHandler { activeTab = AppTab.PLAY }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(RoyalNavyTop, RoyalNavyDeep),
                    center = Offset(500f, 0f),
                    radius = 1400f
                )
            )
    ) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val isExpandedLayout = maxWidth >= 720.dp

            Scaffold(
                containerColor = Color.Transparent,
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
                snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                bottomBar = {
                    if (!isExpandedLayout) {
                        NavigationBar(
                            containerColor = RoyalNavyPanelBottom.copy(alpha = 0.96f),
                            windowInsets = WindowInsets.navigationBars,
                            tonalElevation = 8.dp
                        ) {
                            NavigationBarItem(
                                selected = activeTab == AppTab.PLAY,
                                onClick = { activeTab = AppTab.PLAY },
                                icon = {
                                    Icon(
                                        imageVector = if (activeTab == AppTab.PLAY) Icons.Rounded.Casino else Icons.Outlined.Casino,
                                        contentDescription = null
                                    )
                                },
                                label = { Text(stringResource(R.string.nav_play)) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = RoyalGoldTextOn,
                                    selectedTextColor = RoyalGold,
                                    indicatorColor = RoyalGold,
                                    unselectedIconColor = RoyalTextSecondary,
                                    unselectedTextColor = RoyalTextSecondary
                                ),
                                modifier = Modifier.testTag("nav_play")
                            )
                            NavigationBarItem(
                                selected = activeTab == AppTab.INVITE,
                                onClick = { activeTab = AppTab.INVITE },
                                icon = {
                                    Icon(
                                        imageVector = if (activeTab == AppTab.INVITE) Icons.Rounded.CardGiftcard else Icons.Outlined.CardGiftcard,
                                        contentDescription = null
                                    )
                                },
                                label = { Text(stringResource(R.string.nav_invite)) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = RoyalGoldTextOn,
                                    selectedTextColor = RoyalGold,
                                    indicatorColor = RoyalGold,
                                    unselectedIconColor = RoyalTextSecondary,
                                    unselectedTextColor = RoyalTextSecondary
                                ),
                                modifier = Modifier.testTag("nav_invite")
                            )
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .statusBarsPadding()
                ) {
                    if (isExpandedLayout) {
                        NavigationRail(
                            containerColor = RoyalNavyPanelBottom.copy(alpha = 0.94f),
                            modifier = Modifier.fillMaxHeight()
                        ) {
                            Spacer(Modifier.height(12.dp))
                            NavigationRailItem(
                                selected = activeTab == AppTab.PLAY,
                                onClick = { activeTab = AppTab.PLAY },
                                icon = {
                                    Icon(
                                        imageVector = if (activeTab == AppTab.PLAY) Icons.Rounded.Casino else Icons.Outlined.Casino,
                                        contentDescription = null
                                    )
                                },
                                label = { Text(stringResource(R.string.nav_play)) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = RoyalGoldTextOn,
                                    selectedTextColor = RoyalGold,
                                    indicatorColor = RoyalGold,
                                    unselectedIconColor = RoyalTextSecondary,
                                    unselectedTextColor = RoyalTextSecondary
                                ),
                                modifier = Modifier.testTag("nav_play")
                            )
                            Spacer(Modifier.height(8.dp))
                            NavigationRailItem(
                                selected = activeTab == AppTab.INVITE,
                                onClick = { activeTab = AppTab.INVITE },
                                icon = {
                                    Icon(
                                        imageVector = if (activeTab == AppTab.INVITE) Icons.Rounded.CardGiftcard else Icons.Outlined.CardGiftcard,
                                        contentDescription = null
                                    )
                                },
                                label = { Text(stringResource(R.string.nav_invite)) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = RoyalGoldTextOn,
                                    selectedTextColor = RoyalGold,
                                    indicatorColor = RoyalGold,
                                    unselectedIconColor = RoyalTextSecondary,
                                    unselectedTextColor = RoyalTextSecondary
                                ),
                                modifier = Modifier.testTag("nav_invite")
                            )
                        }
                    }

                    Column(modifier = Modifier.fillMaxSize()) {
                        RoyalHeaderBar(
                            isSoundEnabled = uiState.isSoundEnabled,
                            onToggleSound = viewModel::toggleSound,
                            onOpenProfiles = { editingIdentityPlayer = uiState.currentTurn },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp)
                        )

                        when (activeTab) {
                            AppTab.PLAY -> {
                                PlayGameScreen(
                                    uiState = uiState,
                                    isWideLayout = isExpandedLayout,
                                    onRollDice = viewModel::rollDice,
                                    onTokenClick = viewModel::moveToken,
                                    onPlayerClick = { editingIdentityPlayer = it },
                                    onNewGame = viewModel::resetCurrentGame,
                                    onOpenModeSetup = { showSetupDialog = true },
                                    onOpenRules = { showRulesDialog = true },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            AppTab.INVITE -> {
                                InviteAndRulesScreen(
                                    uiState = uiState,
                                    onShowRefRules = { showRefRulesDialog = true },
                                    onNotifyCopied = { msg ->
                                        coroutineScope.launch {
                                            snackbarHostState.showSnackbar(msg)
                                        }
                                    },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }
        }

        CelebrationParticleOverlay(winner = uiState.winner)
    }

    if (showRulesDialog) {
        RulesDialog(onDismiss = { showRulesDialog = false })
    }

    if (showRefRulesDialog) {
        ReferralRulesDialog(onDismiss = { showRefRulesDialog = false })
    }

    if (showSetupDialog) {
        NewGameSetupDialog(
            initialSeats = uiState.seats,
            identities = uiState.identities,
            onStartGame = { newSeats ->
                viewModel.startNewGame(newSeats)
                showSetupDialog = false
            },
            onDismiss = { showSetupDialog = false }
        )
    }

    val identityPlayer = editingIdentityPlayer
    if (identityPlayer != null) {
        PlayerIdentityDialog(
            initialSelectedPlayer = identityPlayer,
            initialIdentities = uiState.identities,
            onSave = { updated ->
                viewModel.updateAllIdentities(updated)
                editingIdentityPlayer = null
                coroutineScope.launch {
                    snackbarHostState.showSnackbar(profileSavedText)
                }
            },
            onDismiss = { editingIdentityPlayer = null }
        )
    }

    val winner = uiState.winner
    if (winner != null && showWinnerDialogReady && !dismissedWinnerForMatch) {
        WinnerVictoryDialog(
            winner = winner,
            identities = uiState.identities,
            onNewGame = {
                dismissedWinnerForMatch = true
                viewModel.resetCurrentGame()
            },
            onDismiss = { dismissedWinnerForMatch = true }
        )
    }
}

@Composable
private fun RoyalHeaderBar(
    isSoundEnabled: Boolean,
    onToggleSound: () -> Unit,
    onOpenProfiles: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = modifier
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Icon(
                imageVector = Icons.Rounded.WorkspacePremium,
                contentDescription = stringResource(R.string.cd_crown_emblem),
                tint = RoyalGold,
                modifier = Modifier.size(28.dp)
            )
            Spacer(Modifier.width(8.dp))
            Column {
                Text(
                    text = stringResource(R.string.brand_title),
                    style = MaterialTheme.typography.displaySmall,
                    color = RoyalGold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = stringResource(R.string.brand_subtitle),
                    style = MaterialTheme.typography.bodySmall,
                    color = RoyalTextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            IconButton(
                onClick = onOpenProfiles,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("profile_button")
            ) {
                Icon(
                    imageVector = Icons.Rounded.ManageAccounts,
                    contentDescription = stringResource(R.string.cd_edit_profiles),
                    tint = RoyalGold
                )
            }

            IconButton(
                onClick = onToggleSound,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("sound_toggle_button")
            ) {
                Icon(
                    imageVector = if (isSoundEnabled) Icons.Rounded.VolumeUp else Icons.Rounded.VolumeOff,
                    contentDescription = stringResource(
                        if (isSoundEnabled) R.string.cd_sound_on else R.string.cd_sound_off
                    ),
                    tint = if (isSoundEnabled) RoyalGold else RoyalTextMuted
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(30.dp))
                    .background(RoyalNavyPill)
                    .border(1.dp, RoyalNavyPillBorder, RoundedCornerShape(30.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(
                    text = stringResource(R.string.offline_demo_badge),
                    style = MaterialTheme.typography.labelSmall,
                    color = RoyalTextPrimary
                )
            }
        }
    }
}

@Composable
private fun PlayGameScreen(
    uiState: LudoUiState,
    isWideLayout: Boolean,
    onRollDice: () -> Unit,
    onTokenClick: (PlayerColor, Int) -> Unit,
    onPlayerClick: (PlayerColor) -> Unit,
    onNewGame: () -> Unit,
    onOpenModeSetup: () -> Unit,
    onOpenRules: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (isWideLayout) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            modifier = modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .weight(1.1f)
                    .fillMaxHeight()
            ) {
                RoyalLudoBoard(
                    uiState = uiState,
                    onTokenClick = onTokenClick
                )
            }

            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .weight(0.9f)
                    .verticalScroll(rememberScrollState())
                    .clip(RoundedCornerShape(20.dp))
                    .background(Brush.linearGradient(listOf(RoyalNavyPanelTop, RoyalNavyPanelBottom)))
                    .border(1.dp, RoyalNavyBorder, RoundedCornerShape(20.dp))
                    .padding(14.dp)
            ) {
                PlayerHudRow(
                    uiState = uiState,
                    onPlayerClick = onPlayerClick
                )
                TurnControlBar(uiState = uiState, onRollDice = onRollDice)
                ActionButtonRow(
                    onNewGame = onNewGame,
                    onOpenModeSetup = onOpenModeSetup,
                    onOpenRules = onOpenRules
                )
                Text(
                    text = stringResource(R.string.footer_disclaimer),
                    style = MaterialTheme.typography.bodySmall,
                    color = RoyalTextMuted,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    } else {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 4.dp)
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier
                    .widthIn(max = 600.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Brush.linearGradient(listOf(RoyalNavyPanelTop, RoyalNavyPanelBottom)))
                    .border(1.dp, RoyalNavyBorder, RoundedCornerShape(20.dp))
                    .padding(12.dp)
            ) {
                PlayerHudRow(
                    uiState = uiState,
                    onPlayerClick = onPlayerClick
                )
                RoyalLudoBoard(
                    uiState = uiState,
                    onTokenClick = onTokenClick,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
                TurnControlBar(uiState = uiState, onRollDice = onRollDice)
                ActionButtonRow(
                    onNewGame = onNewGame,
                    onOpenModeSetup = onOpenModeSetup,
                    onOpenRules = onOpenRules
                )
            }

            Spacer(Modifier.height(10.dp))
            Text(
                text = stringResource(R.string.footer_disclaimer),
                style = MaterialTheme.typography.bodySmall,
                color = RoyalTextMuted,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }
    }
}

@Composable
private fun ActionButtonRow(
    onNewGame: () -> Unit,
    onOpenModeSetup: () -> Unit,
    onOpenRules: () -> Unit
) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Button(
            onClick = onNewGame,
            colors = ButtonDefaults.buttonColors(
                containerColor = RoyalGold,
                contentColor = RoyalGoldTextOn
            ),
            shape = RoundedCornerShape(12.dp),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp),
            modifier = Modifier.weight(1.2f).testTag("new_game_button")
        ) {
            Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(5.dp))
            Text(
                text = stringResource(R.string.btn_new_game),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        OutlinedButton(
            onClick = onOpenModeSetup,
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.outlinedButtonColors(
                containerColor = RoyalNavySecondaryBtn,
                contentColor = RoyalTextPrimary
            ),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp),
            modifier = Modifier.weight(1f).testTag("mode_button")
        ) {
            Icon(Icons.Rounded.Tune, contentDescription = stringResource(R.string.cd_mode_button), modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            Text(
                text = stringResource(R.string.btn_game_mode),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        OutlinedButton(
            onClick = onOpenRules,
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.outlinedButtonColors(
                containerColor = RoyalNavySecondaryBtn,
                contentColor = RoyalTextPrimary
            ),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp),
            modifier = Modifier.weight(0.9f).testTag("rules_button")
        ) {
            Icon(Icons.Rounded.MenuBook, contentDescription = stringResource(R.string.cd_rules_button), modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            Text(
                text = stringResource(R.string.btn_rules),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
