package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.game.LudoUiState
import com.example.game.toBengaliDigits
import com.example.ui.theme.RoyalGold
import com.example.ui.theme.RoyalGoldTextOn
import com.example.ui.theme.RoyalNavyBorder
import com.example.ui.theme.RoyalNavyCodeBox
import com.example.ui.theme.RoyalNavyCodeDashed
import com.example.ui.theme.RoyalNavyPanelBottom
import com.example.ui.theme.RoyalNavyPanelTop
import com.example.ui.theme.RoyalNavySecondaryBtn
import com.example.ui.theme.RoyalTextMuted
import com.example.ui.theme.RoyalTextPrimary
import com.example.ui.theme.RoyalTextSecondary

@Composable
fun InviteAndRulesScreen(
    uiState: LudoUiState,
    onShowRefRules: () -> Unit,
    onNotifyCopied: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    @Suppress("DEPRECATION")
    val clipboardManager = LocalClipboardManager.current
    var copiedLocally by remember { mutableStateOf(false) }

    val inviteMessage = stringResource(R.string.share_invite_text, uiState.referralCode)
    val copiedStatusText = stringResource(R.string.ref_status_copied)

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.widthIn(max = 600.dp)
        ) {
            // Referral & Invite Panel
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(RoyalNavyPanelTop, RoyalNavyPanelBottom)
                        )
                    )
                    .border(1.dp, RoyalNavyBorder, RoundedCornerShape(20.dp))
                    .padding(16.dp)
            ) {
                Text(
                    text = stringResource(R.string.ref_title),
                    style = MaterialTheme.typography.titleMedium,
                    color = RoyalTextPrimary
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = stringResource(R.string.ref_description),
                    style = MaterialTheme.typography.bodySmall,
                    color = RoyalTextSecondary
                )
                Spacer(Modifier.height(12.dp))

                // Referral Code Box
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(RoyalNavyCodeBox)
                        .border(1.dp, RoyalNavyCodeDashed, RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                ) {
                    Text(
                        text = stringResource(R.string.ref_code_label),
                        style = MaterialTheme.typography.labelSmall,
                        color = RoyalTextMuted
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = uiState.referralCode,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = RoyalGold,
                        modifier = Modifier.weight(1f).testTag("referral_code_text")
                    )
                    Button(
                        onClick = {
                            clipboardManager.setText(AnnotatedString(uiState.referralCode))
                            copiedLocally = true
                            onNotifyCopied(copiedStatusText)
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = RoyalNavySecondaryBtn,
                            contentColor = RoyalTextPrimary
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("copy_referral_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.ContentCopy,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(5.dp))
                        Text(stringResource(R.string.btn_copy))
                    }
                }

                Spacer(Modifier.height(12.dp))

                // Referral Stats Grid
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    StatBox(
                        label = stringResource(R.string.ref_stat_signups),
                        value = uiState.invitedSignups.toBengaliDigits(),
                        modifier = Modifier.weight(1f)
                    )
                    StatBox(
                        label = stringResource(R.string.ref_stat_reward),
                        value = "৳${uiState.approvedRewardBdt.toBengaliDigits()}",
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(Modifier.height(10.dp))
                Text(
                    text = if (copiedLocally) copiedStatusText else stringResource(R.string.ref_status_default),
                    style = MaterialTheme.typography.bodySmall,
                    color = if (copiedLocally) RoyalGold else RoyalTextSecondary
                )
                Spacer(Modifier.height(12.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Button(
                        onClick = {
                            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, inviteMessage)
                            }
                            context.startActivity(Intent.createChooser(sendIntent, null))
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = RoyalGold,
                            contentColor = RoyalGoldTextOn
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f).testTag("share_referral_button")
                    ) {
                        Icon(Icons.Rounded.Share, contentDescription = null, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.btn_invite_friend))
                    }

                    OutlinedButton(
                        onClick = onShowRefRules,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f).testTag("referral_rules_button")
                    ) {
                        Text(stringResource(R.string.btn_view_rules), color = RoyalTextPrimary)
                    }
                }
            }

            // Offline Local Stats Card
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(RoyalNavyPanelTop, RoyalNavyPanelBottom)
                        )
                    )
                    .border(1.dp, RoyalNavyBorder, RoundedCornerShape(20.dp))
                    .padding(16.dp)
            ) {
                Text(
                    text = stringResource(R.string.local_stats_title),
                    style = MaterialTheme.typography.titleMedium,
                    color = RoyalTextPrimary
                )
                Spacer(Modifier.height(10.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    StatBox(
                        label = stringResource(R.string.local_stats_games),
                        value = uiState.totalGamesPlayed.toBengaliDigits(),
                        icon = Icons.Rounded.SportsEsports,
                        modifier = Modifier.weight(1f)
                    )
                    StatBox(
                        label = stringResource(R.string.local_stats_wins),
                        value = uiState.totalWins.toBengaliDigits(),
                        icon = Icons.Rounded.EmojiEvents,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Inline Game Rules Summary Card
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(RoyalNavyPanelTop, RoyalNavyPanelBottom)
                        )
                    )
                    .border(1.dp, RoyalNavyBorder, RoundedCornerShape(20.dp))
                    .padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Rounded.MenuBook,
                        contentDescription = null,
                        tint = RoyalGold,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.rules_title),
                        style = MaterialTheme.typography.titleMedium,
                        color = RoyalTextPrimary
                    )
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    text = stringResource(R.string.rules_body),
                    style = MaterialTheme.typography.bodyMedium,
                    color = RoyalTextSecondary
                )
            }

            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun StatBox(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color.White.copy(alpha = 0.05f))
            .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = RoyalTextMuted,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(Modifier.width(4.dp))
            }
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall,
                color = RoyalTextSecondary
            )
        }
        Spacer(Modifier.height(4.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
            color = RoyalGold
        )
    }
}
