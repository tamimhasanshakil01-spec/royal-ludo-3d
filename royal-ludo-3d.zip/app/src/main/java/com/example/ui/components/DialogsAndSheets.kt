package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.ManageAccounts
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.SmartToy
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.game.PlayerAvatar
import com.example.game.PlayerColor
import com.example.game.PlayerIdentity
import com.example.game.SeatControl
import com.example.game.defaultIdentities
import com.example.ui.theme.RoyalGold
import com.example.ui.theme.RoyalGoldTextOn
import com.example.ui.theme.RoyalNavyBorder
import com.example.ui.theme.RoyalNavyCodeBox
import com.example.ui.theme.RoyalNavyPanelBottom
import com.example.ui.theme.RoyalNavySecondaryBtn
import com.example.ui.theme.RoyalTextMuted
import com.example.ui.theme.RoyalTextPrimary
import com.example.ui.theme.RoyalTextSecondary

@Composable
fun RulesDialog(
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = RoyalNavyPanelBottom,
        titleContentColor = RoyalGold,
        textContentColor = RoyalTextSecondary,
        modifier = Modifier.testTag("rules_dialog"),
        icon = {
            Icon(
                imageVector = Icons.Rounded.MenuBook,
                contentDescription = null,
                tint = RoyalGold
            )
        },
        title = {
            Text(
                text = stringResource(R.string.rules_title),
                style = MaterialTheme.typography.headlineSmall
            )
        },
        text = {
            Text(
                text = stringResource(R.string.rules_body),
                style = MaterialTheme.typography.bodyMedium
            )
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(
                    containerColor = RoyalGold,
                    contentColor = RoyalGoldTextOn
                ),
                modifier = Modifier.testTag("close_rules_button")
            ) {
                Text(stringResource(R.string.btn_close))
            }
        }
    )
}

@Composable
fun ReferralRulesDialog(
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = RoyalNavyPanelBottom,
        titleContentColor = RoyalGold,
        textContentColor = RoyalTextSecondary,
        modifier = Modifier.testTag("referral_rules_dialog"),
        title = {
            Text(
                text = stringResource(R.string.ref_rules_title),
                style = MaterialTheme.typography.headlineSmall
            )
        },
        text = {
            Text(
                text = stringResource(R.string.ref_rules_body),
                style = MaterialTheme.typography.bodyMedium
            )
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(
                    containerColor = RoyalGold,
                    contentColor = RoyalGoldTextOn
                )
            ) {
                Text(stringResource(R.string.btn_close))
            }
        }
    )
}

@Composable
fun NewGameSetupDialog(
    initialSeats: Map<PlayerColor, SeatControl>,
    identities: Map<PlayerColor, PlayerIdentity>,
    onStartGame: (Map<PlayerColor, SeatControl>) -> Unit,
    onDismiss: () -> Unit
) {
    var draftSeats by remember(initialSeats) { mutableStateOf(initialSeats) }
    val activeCount = draftSeats.values.count { it != SeatControl.OFF }
    val isValid = activeCount >= 2

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = RoyalNavyPanelBottom,
        titleContentColor = RoyalGold,
        textContentColor = RoyalTextPrimary,
        modifier = Modifier.testTag("setup_dialog"),
        title = {
            Text(
                text = stringResource(R.string.dialog_setup_title),
                style = MaterialTheme.typography.headlineSmall
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Quick Presets
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    PresetChipRow(
                        label = stringResource(R.string.preset_pass_play),
                        selected = draftSeats.values.all { it == SeatControl.HUMAN },
                        onClick = {
                            draftSeats = PlayerColor.entries.associateWith { SeatControl.HUMAN }
                        }
                    )
                    PresetChipRow(
                        label = stringResource(R.string.preset_vs_bots),
                        selected = draftSeats[PlayerColor.RED] == SeatControl.HUMAN &&
                            draftSeats[PlayerColor.BLUE] == SeatControl.BOT &&
                            draftSeats[PlayerColor.YELLOW] == SeatControl.BOT &&
                            draftSeats[PlayerColor.GREEN] == SeatControl.BOT,
                        onClick = {
                            draftSeats = mapOf(
                                PlayerColor.RED to SeatControl.HUMAN,
                                PlayerColor.BLUE to SeatControl.BOT,
                                PlayerColor.YELLOW to SeatControl.BOT,
                                PlayerColor.GREEN to SeatControl.BOT
                            )
                        }
                    )
                    PresetChipRow(
                        label = stringResource(R.string.preset_duel),
                        selected = draftSeats[PlayerColor.RED] == SeatControl.HUMAN &&
                            draftSeats[PlayerColor.BLUE] == SeatControl.OFF &&
                            draftSeats[PlayerColor.YELLOW] == SeatControl.HUMAN &&
                            draftSeats[PlayerColor.GREEN] == SeatControl.OFF,
                        onClick = {
                            draftSeats = mapOf(
                                PlayerColor.RED to SeatControl.HUMAN,
                                PlayerColor.BLUE to SeatControl.OFF,
                                PlayerColor.YELLOW to SeatControl.HUMAN,
                                PlayerColor.GREEN to SeatControl.OFF
                            )
                        }
                    )
                }

                Spacer(Modifier.height(2.dp))

                // Individual seat selectors
                PlayerColor.entries.forEach { player ->
                    val currentControl = draftSeats[player] ?: SeatControl.HUMAN
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.White.copy(alpha = 0.05f))
                            .border(1.dp, RoyalNavyBorder, RoundedCornerShape(12.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f).padding(end = 6.dp)
                        ) {
                            val avatar = identities[player]?.avatar ?: PlayerAvatar.defaultForColor(player)
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(20.dp)
                                    .clip(CircleShape)
                                    .background(player.baseColor)
                            ) {
                                Icon(
                                    imageVector = avatarIcon(avatar),
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = playerDisplayName(player, identities),
                                style = MaterialTheme.typography.titleSmall,
                                color = RoyalTextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            SeatOptionPill(
                                label = stringResource(R.string.seat_human),
                                icon = Icons.Rounded.Person,
                                selected = currentControl == SeatControl.HUMAN,
                                onClick = { draftSeats = draftSeats + (player to SeatControl.HUMAN) }
                            )
                            SeatOptionPill(
                                label = stringResource(R.string.seat_bot),
                                icon = Icons.Rounded.SmartToy,
                                selected = currentControl == SeatControl.BOT,
                                onClick = { draftSeats = draftSeats + (player to SeatControl.BOT) }
                            )
                            SeatOptionPill(
                                label = stringResource(R.string.seat_off),
                                icon = Icons.Rounded.Block,
                                selected = currentControl == SeatControl.OFF,
                                onClick = { draftSeats = draftSeats + (player to SeatControl.OFF) }
                            )
                        }
                    }
                }

                if (!isValid) {
                    Text(
                        text = stringResource(R.string.setup_seat_hint),
                        style = MaterialTheme.typography.bodySmall,
                        color = RoyalGold
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onStartGame(draftSeats) },
                enabled = isValid,
                colors = ButtonDefaults.buttonColors(
                    containerColor = RoyalGold,
                    contentColor = RoyalGoldTextOn
                ),
                modifier = Modifier.testTag("confirm_start_game")
            ) {
                Text(stringResource(R.string.btn_start_game))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.btn_close), color = RoyalTextSecondary)
            }
        }
    )
}

@Composable
private fun PresetChipRow(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = {
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium
            )
        },
        colors = FilterChipDefaults.filterChipColors(
            containerColor = RoyalNavySecondaryBtn.copy(alpha = 0.55f),
            labelColor = RoyalTextPrimary,
            selectedContainerColor = RoyalGold,
            selectedLabelColor = RoyalGoldTextOn
        ),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun SeatOptionPill(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    onClick: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (selected) RoyalGold else RoyalNavySecondaryBtn)
            .clickable(onClick = onClick)
            .padding(horizontal = 7.dp, vertical = 6.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (selected) RoyalGoldTextOn else RoyalTextSecondary,
            modifier = Modifier.size(13.dp)
        )
        Spacer(Modifier.width(3.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = if (selected) RoyalGoldTextOn else RoyalTextPrimary
        )
    }
}

@Composable
fun WinnerVictoryDialog(
    winner: PlayerColor,
    identities: Map<PlayerColor, PlayerIdentity>,
    onNewGame: () -> Unit,
    onDismiss: () -> Unit
) {
    val winnerName = playerDisplayName(winner, identities)
    val winnerAvatar = identities[winner]?.avatar ?: PlayerAvatar.defaultForColor(winner)
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = RoyalNavyPanelBottom,
        titleContentColor = RoyalGold,
        textContentColor = RoyalTextPrimary,
        modifier = Modifier.testTag("winner_dialog"),
        icon = {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(winner.baseColor.copy(alpha = 0.25f))
                    .border(2.dp, RoyalGold, CircleShape)
            ) {
                Icon(
                    imageVector = avatarIcon(winnerAvatar),
                    contentDescription = null,
                    tint = RoyalGold,
                    modifier = Modifier.size(32.dp)
                )
            }
        },
        title = {
            Text(
                text = stringResource(R.string.winner_label, winnerName),
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Text(
                text = stringResource(R.string.hint_victory, winnerName),
                style = MaterialTheme.typography.bodyLarge,
                color = RoyalTextSecondary
            )
        },
        confirmButton = {
            Button(
                onClick = onNewGame,
                colors = ButtonDefaults.buttonColors(
                    containerColor = RoyalGold,
                    contentColor = RoyalGoldTextOn
                ),
                modifier = Modifier.testTag("winner_new_game_button")
            ) {
                Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(stringResource(R.string.btn_new_game))
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text(stringResource(R.string.btn_close), color = RoyalTextSecondary)
            }
        }
    )
}

@Composable
fun PlayerIdentityDialog(
    initialSelectedPlayer: PlayerColor,
    initialIdentities: Map<PlayerColor, PlayerIdentity>,
    onSave: (Map<PlayerColor, PlayerIdentity>) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedPlayer by remember(initialSelectedPlayer) { mutableStateOf(initialSelectedPlayer) }
    var draftIdentities by remember(initialIdentities) { mutableStateOf(initialIdentities) }

    val currentIdentity = draftIdentities[selectedPlayer]
        ?: PlayerIdentity(avatar = PlayerAvatar.defaultForColor(selectedPlayer))
    val defaultColorLabel = playerDisplayName(selectedPlayer)

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = RoyalNavyPanelBottom,
        titleContentColor = RoyalGold,
        textContentColor = RoyalTextPrimary,
        modifier = Modifier.testTag("identity_dialog"),
        icon = {
            Icon(
                imageVector = Icons.Rounded.ManageAccounts,
                contentDescription = null,
                tint = RoyalGold
            )
        },
        title = {
            Text(
                text = stringResource(R.string.dialog_identity_title),
                style = MaterialTheme.typography.headlineSmall
            )
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.verticalScroll(rememberScrollState())
            ) {
                // Player seat tabs
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    PlayerColor.entries.forEach { player ->
                        val isSelected = player == selectedPlayer
                        val seatIdentity = draftIdentities[player]
                        val avatar = seatIdentity?.avatar ?: PlayerAvatar.defaultForColor(player)
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) player.baseColor.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.05f))
                                .border(
                                    width = if (isSelected) 1.8.dp else 1.dp,
                                    color = if (isSelected) RoyalGold else RoyalNavyBorder,
                                    shape = RoundedCornerShape(10.dp)
                                )
                                .clickable { selectedPlayer = player }
                                .padding(vertical = 8.dp, horizontal = 4.dp)
                                .testTag("identity_tab_${player.name.lowercase()}")
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(22.dp)
                                    .clip(CircleShape)
                                    .background(player.baseColor)
                            ) {
                                Icon(
                                    imageVector = avatarIcon(avatar),
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(13.dp)
                                )
                            }
                            Spacer(Modifier.height(3.dp))
                            Text(
                                text = playerDisplayName(player, draftIdentities),
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isSelected) RoyalGold else RoyalTextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                // Nickname input
                OutlinedTextField(
                    value = currentIdentity.nickname,
                    onValueChange = { raw ->
                        val trimmed = raw.take(16)
                        draftIdentities = draftIdentities + (
                            selectedPlayer to currentIdentity.copy(nickname = trimmed)
                        )
                    },
                    singleLine = true,
                    label = { Text(stringResource(R.string.identity_nickname_label)) },
                    placeholder = {
                        Text(
                            text = stringResource(R.string.identity_nickname_placeholder, defaultColorLabel),
                            color = RoyalTextMuted
                        )
                    },
                    trailingIcon = {
                        if (currentIdentity.nickname.isNotEmpty()) {
                            IconButton(
                                onClick = {
                                    draftIdentities = draftIdentities + (
                                        selectedPlayer to currentIdentity.copy(nickname = "")
                                    )
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Clear,
                                    contentDescription = stringResource(R.string.cd_clear_nickname),
                                    tint = RoyalTextSecondary
                                )
                            }
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = RoyalGold,
                        unfocusedBorderColor = RoyalNavyBorder,
                        focusedLabelColor = RoyalGold,
                        unfocusedLabelColor = RoyalTextSecondary,
                        focusedTextColor = RoyalTextPrimary,
                        unfocusedTextColor = RoyalTextPrimary,
                        focusedContainerColor = RoyalNavyCodeBox,
                        unfocusedContainerColor = RoyalNavyCodeBox,
                        cursorColor = RoyalGold
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("identity_nickname_input")
                )

                Text(
                    text = stringResource(R.string.identity_avatar_label),
                    style = MaterialTheme.typography.labelLarge,
                    color = RoyalTextSecondary
                )

                // 2x4 grid of royal avatars
                val avatars = PlayerAvatar.entries
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (rowIndex in 0 until 2) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            for (colIndex in 0 until 4) {
                                val avatar = avatars[rowIndex * 4 + colIndex]
                                val isChosen = currentIdentity.avatar == avatar
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier
                                        .weight(1f)
                                        .minimumInteractiveComponentSize()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(
                                            if (isChosen) selectedPlayer.baseColor.copy(alpha = 0.28f)
                                            else Color.White.copy(alpha = 0.05f)
                                        )
                                        .border(
                                            width = if (isChosen) 2.dp else 1.dp,
                                            color = if (isChosen) RoyalGold else RoyalNavyBorder,
                                            shape = RoundedCornerShape(12.dp)
                                        )
                                        .clickable {
                                            draftIdentities = draftIdentities + (
                                                selectedPlayer to currentIdentity.copy(avatar = avatar)
                                            )
                                        }
                                        .padding(vertical = 8.dp, horizontal = 4.dp)
                                        .testTag("avatar_option_${avatar.name.lowercase()}")
                                ) {
                                    Icon(
                                        imageVector = avatarIcon(avatar),
                                        contentDescription = avatarLabel(avatar),
                                        tint = if (isChosen) RoyalGold else RoyalTextPrimary,
                                        modifier = Modifier.size(22.dp)
                                    )
                                    Spacer(Modifier.height(2.dp))
                                    Text(
                                        text = avatarLabel(avatar),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (isChosen) RoyalGold else RoyalTextSecondary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(draftIdentities) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = RoyalGold,
                    contentColor = RoyalGoldTextOn
                ),
                modifier = Modifier.testTag("save_identity_button")
            ) {
                Text(stringResource(R.string.btn_save))
            }
        },
        dismissButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(
                    onClick = { draftIdentities = defaultIdentities() },
                    modifier = Modifier.testTag("reset_identity_button")
                ) {
                    Text(stringResource(R.string.btn_reset_profiles), color = RoyalTextMuted)
                }
                TextButton(onClick = onDismiss) {
                    Text(stringResource(R.string.btn_close), color = RoyalTextSecondary)
                }
            }
        }
    )
}
