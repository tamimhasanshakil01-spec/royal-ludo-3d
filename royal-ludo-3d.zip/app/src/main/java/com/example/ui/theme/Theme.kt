package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val RoyalDarkColorScheme = darkColorScheme(
    primary = RoyalGold,
    onPrimary = RoyalGoldTextOn,
    primaryContainer = RoyalNavyPill,
    onPrimaryContainer = RoyalGold,
    secondary = RoyalNavySecondaryBtn,
    onSecondary = RoyalTextPrimary,
    secondaryContainer = RoyalNavyPanelTop,
    onSecondaryContainer = RoyalTextSecondary,
    tertiary = LudoBlueBase,
    onTertiary = RoyalTextPrimary,
    background = RoyalNavyDeep,
    onBackground = RoyalTextPrimary,
    surface = RoyalNavyPanelBottom,
    onSurface = RoyalTextPrimary,
    surfaceVariant = RoyalNavyPanelTop,
    onSurfaceVariant = RoyalTextSecondary,
    outline = RoyalNavyBorder,
    outlineVariant = RoyalNavyPillBorder,
    error = LudoRedBase,
    onError = RoyalTextPrimary
)

val RoyalShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp)
)

@Composable
fun RoyalLudoTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = RoyalDarkColorScheme,
        typography = RoyalTypography,
        shapes = RoyalShapes,
        content = content
    )
}
