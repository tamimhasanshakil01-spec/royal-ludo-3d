package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.game.BoardCoord
import com.example.game.LudoBoardGeometry
import com.example.game.LudoUiState
import com.example.game.PlayerColor
import com.example.game.SeatControl
import com.example.game.TokenRenderPos
import com.example.ui.theme.BoardGridLine
import com.example.ui.theme.BoardParchment
import com.example.ui.theme.BoardSafeCell
import com.example.ui.theme.BoardTrackCell
import com.example.ui.theme.BoardWoodDark
import com.example.ui.theme.BoardWoodFrame
import com.example.ui.theme.BoardWoodLight
import com.example.ui.theme.RoyalGold
import com.example.ui.theme.RoyalGoldDeep
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun RoyalLudoBoard(
    uiState: LudoUiState,
    onTokenClick: (PlayerColor, Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current
    val infiniteTransition = rememberInfiniteTransition(label = "movable_pulse")
    val pulseFraction by infiniteTransition.animateFloat(
        initialValue = 0.88f,
        targetValue = 1.18f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 650, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    Box(
        modifier = modifier
            .widthIn(max = 520.dp)
            .aspectRatio(1f)
            .shadow(16.dp, RoundedCornerShape(22.dp))
            .clip(RoundedCornerShape(22.dp))
            .background(
                brush = Brush.linearGradient(
                    colors = listOf(BoardWoodLight, BoardWoodDark)
                )
            )
            .border(1.5.dp, Color.White.copy(alpha = 0.45f), RoundedCornerShape(22.dp))
            .padding(9.dp)
    ) {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(10.dp))
                .background(BoardParchment)
                .border(2.5.dp, BoardWoodFrame, RoundedCornerShape(10.dp))
        ) {
            val boardPx = with(LocalDensity.current) { maxWidth.toPx() }
            val cellDp = maxWidth / LudoBoardGeometry.GRID_SIZE

            // Static + themed 15x15 Ludo Board Canvas
            Canvas(modifier = Modifier.fillMaxSize()) {
                val cellSize = size.width / LudoBoardGeometry.GRID_SIZE
                drawTrackCells(cellSize)
                drawHomeStretches(cellSize)
                drawHomeYards(cellSize)
                drawCenterGoal(cellSize)
            }

            // Prepare token placements grouped by cell coordinate (for non-yard, non-goal tokens)
            val allTokens = remember(uiState.pieces, uiState.currentTurn, uiState.movableTokenIndices, uiState.hasRolled, uiState.seats) {
                buildList {
                    PlayerColor.entries.forEach { player ->
                        if (uiState.seats[player] != SeatControl.OFF) {
                            val list = uiState.pieces[player].orEmpty()
                            list.forEachIndexed { idx, progress ->
                                val movable = player == uiState.currentTurn &&
                                    uiState.hasRolled &&
                                    !uiState.isRollingDice &&
                                    uiState.seats[player] == SeatControl.HUMAN &&
                                    idx in uiState.movableTokenIndices
                                add(TokenRenderPos(player, idx, progress, movable))
                            }
                        }
                    }
                }
            }

            val cellGroups = remember(allTokens) {
                allTokens.filter {
                    it.progress in 0..55
                }.groupBy { token ->
                    LudoBoardGeometry.coordForProgress(token.player, token.progress)
                }
            }

            // Render tokens in Home Yards, on Track/Home Stretch, and in Center Goal
            allTokens.forEach { token ->
                val (centerGridX, centerGridY, tokenScale) = when {
                    token.progress == LudoBoardGeometry.HOME_YARD -> {
                        val homeTop = token.player.homeTopLeft
                        val slotRow = token.tokenIndex / 2
                        val slotCol = token.tokenIndex % 2
                        // 6x6 yard -> inner box starts at +0.72 cells, slots centered at ~1.9 and 4.1
                        val gx = homeTop.col + if (slotCol == 0) 2.0f else 4.0f
                        val gy = homeTop.row + if (slotRow == 0) 2.0f else 4.0f
                        Triple(gx, gy, 0.92f)
                    }
                    token.progress == LudoBoardGeometry.GOAL_PROGRESS -> {
                        val goalPieces = allTokens.filter {
                            it.player == token.player && it.progress == LudoBoardGeometry.GOAL_PROGRESS
                        }
                        val stackIdx = goalPieces.indexOfFirst { it.tokenIndex == token.tokenIndex }.coerceAtLeast(0)
                        val (baseX, baseY) = LudoBoardGeometry.goalCoord(token.player)
                        val spread = (stackIdx - (goalPieces.size - 1) / 2f) * 0.24f
                        val (gx, gy) = when (token.player) {
                            PlayerColor.RED, PlayerColor.YELLOW -> baseX to (baseY + spread)
                            PlayerColor.BLUE, PlayerColor.GREEN -> (baseX + spread) to baseY
                        }
                        Triple(gx, gy, 0.56f)
                    }
                    else -> {
                        val coord = LudoBoardGeometry.coordForProgress(token.player, token.progress)
                        val group = coord?.let { cellGroups[it] }.orEmpty()
                        val idxInGroup = group.indexOfFirst {
                            it.player == token.player && it.tokenIndex == token.tokenIndex
                        }.coerceAtLeast(0)
                        val baseX = (coord?.col ?: 0) + 0.5f
                        val baseY = (coord?.row ?: 0) + 0.5f
                        if (group.size <= 1) {
                            Triple(baseX, baseY, 0.78f)
                        } else {
                            val subOffsets = listOf(
                                -0.21f to -0.21f,
                                0.21f to -0.21f,
                                -0.21f to 0.21f,
                                0.21f to 0.21f
                            )
                            val (ox, oy) = subOffsets[idxInGroup % subOffsets.size]
                            Triple(baseX + ox, baseY + oy, 0.56f)
                        }
                    }
                }

                val visualSize: Dp = cellDp * tokenScale
                val hitSize: Dp = if (token.isMovable) maxOf(visualSize, 48.dp) else maxOf(visualSize, 30.dp)
                val targetX = cellDp * centerGridX - hitSize / 2
                val targetY = cellDp * centerGridY - hitSize / 2

                val animX by animateDpAsState(
                    targetValue = targetX,
                    animationSpec = spring(dampingRatio = 0.72f, stiffness = 420f),
                    label = "token_x_${token.player}_${token.tokenIndex}"
                )
                val animY by animateDpAsState(
                    targetValue = targetY,
                    animationSpec = spring(dampingRatio = 0.72f, stiffness = 420f),
                    label = "token_y_${token.player}_${token.tokenIndex}"
                )

                val playerName = when (token.player) {
                    PlayerColor.RED -> stringResource(R.string.player_red)
                    PlayerColor.BLUE -> stringResource(R.string.player_blue)
                    PlayerColor.YELLOW -> stringResource(R.string.player_yellow)
                    PlayerColor.GREEN -> stringResource(R.string.player_green)
                }
                val tokenCd = stringResource(R.string.cd_token_piece, playerName, token.tokenIndex + 1)

                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .offset(x = animX, y = animY)
                        .size(hitSize)
                        .testTag("token_${token.player.name.lowercase()}_${token.tokenIndex}")
                        .semantics { contentDescription = tokenCd }
                        .then(
                            if (token.isMovable) {
                                Modifier.clickable(
                                    interactionSource = remember { MutableInteractionSource() },
                                    indication = null,
                                    role = Role.Button
                                ) {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    onTokenClick(token.player, token.tokenIndex)
                                }
                            } else {
                                Modifier
                            }
                        )
                ) {
                    if (token.isMovable) {
                        Box(
                            modifier = Modifier
                                .size(visualSize * pulseFraction)
                                .clip(CircleShape)
                                .border(2.5.dp, RoyalGold, CircleShape)
                                .background(RoyalGold.copy(alpha = 0.25f), CircleShape)
                        )
                    }

                    // 3D Glossy Pawn Token
                    Canvas(modifier = Modifier.size(visualSize)) {
                        val r = size.minDimension / 2f
                        val center = Offset(size.width / 2f, size.height / 2f)

                        // Drop shadow
                        drawCircle(
                            color = Color.Black.copy(alpha = 0.35f),
                            radius = r * 0.96f,
                            center = Offset(center.x, center.y + r * 0.14f)
                        )
                        // White outer collar
                        drawCircle(
                            color = Color.White,
                            radius = r * 0.94f,
                            center = center
                        )
                        // 3D shaded sphere body
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    token.player.lightColor,
                                    token.player.baseColor,
                                    token.player.darkColor
                                ),
                                center = Offset(center.x - r * 0.28f, center.y - r * 0.28f),
                                radius = r * 1.25f
                            ),
                            radius = r * 0.78f,
                            center = center
                        )
                        // Subtle inner crown/ring
                        drawCircle(
                            color = Color.White.copy(alpha = 0.45f),
                            radius = r * 0.40f,
                            center = center,
                            style = Stroke(width = (r * 0.11f).coerceAtLeast(1.2f))
                        )
                    }
                }
            }
        }
    }
}

private fun DrawScope.drawTrackCells(cellSize: Float) {
    LudoBoardGeometry.outerTrack.forEachIndexed { index, coord ->
        val left = coord.col * cellSize
        val top = coord.row * cellSize
        val startPlayer = LudoBoardGeometry.startArrowPlayer(index)
        val isSafe = index in LudoBoardGeometry.safeTrackIndices

        val fillColor = when {
            startPlayer != null -> startPlayer.baseColor.copy(alpha = 0.24f)
            isSafe -> BoardSafeCell
            else -> BoardTrackCell
        }

        drawRect(
            color = fillColor,
            topLeft = Offset(left, top),
            size = Size(cellSize, cellSize)
        )
        drawRect(
            color = BoardGridLine,
            topLeft = Offset(left, top),
            size = Size(cellSize, cellSize),
            style = Stroke(width = 1.dp.toPx())
        )

        if (startPlayer != null) {
            // Colored start cell accent badge
            drawCircle(
                color = startPlayer.baseColor.copy(alpha = 0.85f),
                radius = cellSize * 0.26f,
                center = Offset(left + cellSize / 2f, top + cellSize / 2f)
            )
            drawStar(
                center = Offset(left + cellSize / 2f, top + cellSize / 2f),
                outerRadius = cellSize * 0.16f,
                color = Color.White
            )
        } else if (index in LudoBoardGeometry.starTrackIndices) {
            drawStar(
                center = Offset(left + cellSize / 2f, top + cellSize / 2f),
                outerRadius = cellSize * 0.29f,
                color = BoardWoodFrame.copy(alpha = 0.75f)
            )
        }
    }
}

private fun DrawScope.drawHomeStretches(cellSize: Float) {
    LudoBoardGeometry.homeStretches.forEach { (player, coords) ->
        coords.forEach { coord ->
            val left = coord.col * cellSize
            val top = coord.row * cellSize
            drawRect(
                color = player.baseColor.copy(alpha = 0.88f),
                topLeft = Offset(left, top),
                size = Size(cellSize, cellSize)
            )
            drawRect(
                color = Color.White.copy(alpha = 0.45f),
                topLeft = Offset(left, top),
                size = Size(cellSize, cellSize),
                style = Stroke(width = 1.dp.toPx())
            )
        }
    }
}

private fun DrawScope.drawHomeYards(cellSize: Float) {
    PlayerColor.entries.forEach { player ->
        val topLeftCoord = player.homeTopLeft
        val yardLeft = topLeftCoord.col * cellSize
        val yardTop = topLeftCoord.row * cellSize
        val yardSize = cellSize * 6f

        // Colored yard background with subtle gradient
        drawRect(
            brush = Brush.linearGradient(
                colors = listOf(player.baseColor, player.darkColor),
                start = Offset(yardLeft, yardTop),
                end = Offset(yardLeft + yardSize, yardTop + yardSize)
            ),
            topLeft = Offset(yardLeft, yardTop),
            size = Size(yardSize, yardSize)
        )
        drawRect(
            color = BoardWoodFrame.copy(alpha = 0.65f),
            topLeft = Offset(yardLeft, yardTop),
            size = Size(yardSize, yardSize),
            style = Stroke(width = 1.5.dp.toPx())
        )

        // Inner white rounded yard box
        val inset = cellSize * 0.72f
        val boxLeft = yardLeft + inset
        val boxTop = yardTop + inset
        val boxSize = yardSize - inset * 2f
        val cornerRadius = boxSize * 0.14f

        drawRoundRect(
            color = Color.Black.copy(alpha = 0.18f),
            topLeft = Offset(boxLeft, boxTop + 2.dp.toPx()),
            size = Size(boxSize, boxSize),
            cornerRadius = CornerRadius(cornerRadius, cornerRadius)
        )
        drawRoundRect(
            color = BoardTrackCell,
            topLeft = Offset(boxLeft, boxTop),
            size = Size(boxSize, boxSize),
            cornerRadius = CornerRadius(cornerRadius, cornerRadius)
        )

        // 4 circular token slots inside the home box
        val slotRadius = cellSize * 0.56f
        for (r in 0..1) {
            for (c in 0..1) {
                val cx = yardLeft + cellSize * (if (c == 0) 2.0f else 4.0f)
                val cy = yardTop + cellSize * (if (r == 0) 2.0f else 4.0f)
                drawCircle(
                    color = player.baseColor.copy(alpha = 0.22f),
                    radius = slotRadius,
                    center = Offset(cx, cy)
                )
                drawCircle(
                    color = player.baseColor.copy(alpha = 0.65f),
                    radius = slotRadius,
                    center = Offset(cx, cy),
                    style = Stroke(width = 1.5.dp.toPx())
                )
            }
        }
    }
}

private fun DrawScope.drawCenterGoal(cellSize: Float) {
    val left = cellSize * 6f
    val top = cellSize * 6f
    val boxSize = cellSize * 3f
    val right = left + boxSize
    val bottom = top + boxSize
    val center = Offset(left + boxSize / 2f, top + boxSize / 2f)

    // Left triangle = RED
    drawPath(
        path = Path().apply {
            moveTo(left, top)
            lineTo(center.x, center.y)
            lineTo(left, bottom)
            close()
        },
        color = PlayerColor.RED.baseColor
    )
    // Top triangle = BLUE
    drawPath(
        path = Path().apply {
            moveTo(left, top)
            lineTo(right, top)
            lineTo(center.x, center.y)
            close()
        },
        color = PlayerColor.BLUE.baseColor
    )
    // Right triangle = YELLOW
    drawPath(
        path = Path().apply {
            moveTo(right, top)
            lineTo(right, bottom)
            lineTo(center.x, center.y)
            close()
        },
        color = PlayerColor.YELLOW.baseColor
    )
    // Bottom triangle = GREEN
    drawPath(
        path = Path().apply {
            moveTo(left, bottom)
            lineTo(center.x, center.y)
            lineTo(right, bottom)
            close()
        },
        color = PlayerColor.GREEN.baseColor
    )

    // Crisp diagonal dividers
    drawLine(Color.White.copy(alpha = 0.85f), Offset(left, top), Offset(right, bottom), strokeWidth = 1.5.dp.toPx())
    drawLine(Color.White.copy(alpha = 0.85f), Offset(right, top), Offset(left, bottom), strokeWidth = 1.5.dp.toPx())
    drawRect(
        color = BoardWoodFrame,
        topLeft = Offset(left, top),
        size = Size(boxSize, boxSize),
        style = Stroke(width = 1.5.dp.toPx())
    )

    // Center golden royal medallion
    val medalRadius = cellSize * 0.48f
    drawCircle(color = RoyalGoldDeep, radius = medalRadius, center = center)
    drawCircle(color = RoyalGold, radius = medalRadius * 0.84f, center = center)
    drawStar(center = center, outerRadius = medalRadius * 0.56f, color = Color.White)
}

private fun DrawScope.drawStar(center: Offset, outerRadius: Float, color: Color) {
    val innerRadius = outerRadius * 0.44f
    val path = Path()
    for (i in 0 until 10) {
        val angle = -PI / 2.0 + i * (PI / 5.0)
        val radius = if (i % 2 == 0) outerRadius else innerRadius
        val x = center.x + (cos(angle) * radius).toFloat()
        val y = center.y + (sin(angle) * radius).toFloat()
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    drawPath(
        path = path,
        color = color,
        style = androidx.compose.ui.graphics.drawscope.Fill
    )
    drawPath(
        path = path,
        color = color,
        style = Stroke(width = 0.6f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    )
}
