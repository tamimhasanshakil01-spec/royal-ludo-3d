package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core Royal Navy & Gold Surface Palette
val RoyalNavyDeep = Color(0xFF10182D)
val RoyalNavyTop = Color(0xFF26395F)
val RoyalNavyPanelTop = Color(0xFF263858)
val RoyalNavyPanelBottom = Color(0xFF17243D)
val RoyalNavyBorder = Color(0xFF425779)
val RoyalNavyPill = Color(0xFF243654)
val RoyalNavyPillBorder = Color(0xFF52698C)
val RoyalNavySecondaryBtn = Color(0xFF314665)
val RoyalNavyCodeBox = Color(0xFF101B30)
val RoyalNavyCodeDashed = Color(0xFF7185A8)

val RoyalGold = Color(0xFFF4C76B)
val RoyalGoldDeep = Color(0xFFC8922A)
val RoyalGoldTextOn = Color(0xFF17243D)
val RoyalTextPrimary = Color(0xFFFFFFFF)
val RoyalTextSecondary = Color(0xFFC5D2E8)
val RoyalTextMuted = Color(0xFF9EB0CC)

// Wooden & Parchment Ludo Board Palette
val BoardWoodLight = Color(0xFFE6D5AD)
val BoardWoodDark = Color(0xFF9F8558)
val BoardWoodFrame = Color(0xFF705A37)
val BoardParchment = Color(0xFFF7F1E4)
val BoardTrackCell = Color(0xFFFFFDF6)
val BoardSafeCell = Color(0xFFF5E3AD)
val BoardGridLine = Color(0x66B9AA8C)

// 3D Dice Palette
val DiceFaceTop = Color(0xFFFFFFFF)
val DiceFaceBottom = Color(0xFFD8DFEB)
val DiceLipShadow = Color(0xFF9CA8BA)
val DicePipColor = Color(0xFF17243D)

// Player Colors with 3D Highlight & Shadow Stops
val LudoRedBase = Color(0xFFE34242)
val LudoRedLight = Color(0xFFFF9999)
val LudoRedDark = Color(0xFFC92035)

val LudoBlueBase = Color(0xFF4388EF)
val LudoBlueLight = Color(0xFF9AC7FF)
val LudoBlueDark = Color(0xFF1554BD)

val LudoYellowBase = Color(0xFFF2C94C)
val LudoYellowLight = Color(0xFFFFF0A0)
val LudoYellowDark = Color(0xFFC18B08)

val LudoGreenBase = Color(0xFF35B978)
val LudoGreenLight = Color(0xFF9AF0BD)
val LudoGreenDark = Color(0xFF13824D)
