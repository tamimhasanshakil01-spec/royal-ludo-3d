package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.game.PlayerColor
import com.example.ui.theme.RoyalGold
import com.example.ui.theme.RoyalGoldDeep
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

private enum class ParticleShape {
    CONFETTI,
    STAR,
    SPARK
}

private data class CelebrationParticle(
    val originNormX: Float,
    val originNormY: Float,
    val vxNorm: Float,
    val vyNorm: Float,
    val gravityNorm: Float,
    val drag: Float,
    val sizeDp: Float,
    val color: Color,
    val shape: ParticleShape,
    val startDelaySec: Float,
    val lifetimeSec: Float,
    val initialRotationDeg: Float,
    val angularVelDeg: Float,
    val tumblePhase: Float,
    val tumbleSpeed: Float
)

@Composable
fun CelebrationParticleOverlay(
    winner: PlayerColor?,
    modifier: Modifier = Modifier
) {
    if (winner == null) return

    val particles = remember(winner) {
        buildCelebrationParticles(winner)
    }

    var elapsedNanos by remember(winner) { mutableLongStateOf(0L) }
    val totalDurationSec = 3.6f

    LaunchedEffect(winner) {
        elapsedNanos = 0L
        var startNanos = 0L
        while (true) {
            val frameNanos = withFrameNanos { it }
            if (startNanos == 0L) {
                startNanos = frameNanos
            }
            val elapsed = (frameNanos - startNanos)
            elapsedNanos = elapsed
            if (elapsed / 1_000_000_000f >= totalDurationSec) {
                break
            }
        }
    }

    val elapsedSec = elapsedNanos / 1_000_000_000f
    if (elapsedSec >= totalDurationSec) return

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .testTag("celebration_particle_overlay")
    ) {
        val w = size.width
        val h = size.height
        val minDim = size.minDimension

        particles.forEach { p ->
            val localT = elapsedSec - p.startDelaySec
            if (localT <= 0f || localT >= p.lifetimeSec) return@forEach

            val lifeRatio = (localT / p.lifetimeSec).coerceIn(0f, 1f)
            val alpha = when {
                lifeRatio < 0.08f -> lifeRatio / 0.08f
                lifeRatio > 0.65f -> (1f - lifeRatio) / 0.35f
                else -> 1f
            }.coerceIn(0f, 1f)

            // Smooth air resistance + gravity kinematics
            val dragFactor = (1f - kotlin.math.exp(-p.drag * localT)) / p.drag
            val x = (p.originNormX + p.vxNorm * dragFactor) * w
            val y = (p.originNormY + p.vyNorm * dragFactor + 0.5f * p.gravityNorm * localT * localT) * h

            if (x < -80f || x > w + 80f || y > h + 80f) return@forEach

            val basePx = p.sizeDp.dp.toPx() * (minDim / 400f).coerceIn(0.85f, 1.45f)
            val rotation = p.initialRotationDeg + p.angularVelDeg * localT
            val drawColor = p.color.copy(alpha = alpha)

            when (p.shape) {
                ParticleShape.CONFETTI -> {
                    val tumbleScale = (0.32f + 0.68f * kotlin.math.abs(cos(p.tumblePhase + p.tumbleSpeed * localT)))
                    val rectW = basePx * 1.15f
                    val rectH = basePx * 0.58f * tumbleScale
                    rotate(degrees = rotation, pivot = Offset(x, y)) {
                        drawRect(
                            color = drawColor,
                            topLeft = Offset(x - rectW / 2f, y - rectH / 2f),
                            size = Size(rectW, rectH)
                        )
                    }
                }
                ParticleShape.STAR -> {
                    rotate(degrees = rotation, pivot = Offset(x, y)) {
                        drawCelebrationStar(
                            center = Offset(x, y),
                            outerRadius = basePx * 0.72f,
                            color = drawColor
                        )
                    }
                }
                ParticleShape.SPARK -> {
                    drawCircle(
                        color = drawColor.copy(alpha = alpha * 0.35f),
                        radius = basePx * 0.68f,
                        center = Offset(x, y)
                    )
                    drawCircle(
                        color = drawColor,
                        radius = basePx * 0.36f,
                        center = Offset(x, y)
                    )
                }
            }
        }
    }
}

private fun buildCelebrationParticles(winner: PlayerColor): List<CelebrationParticle> {
    val palette = listOf(
        winner.baseColor,
        winner.lightColor,
        RoyalGold,
        RoyalGoldDeep,
        Color.White,
        PlayerColor.RED.lightColor,
        PlayerColor.BLUE.lightColor,
        PlayerColor.GREEN.lightColor,
        PlayerColor.YELLOW.lightColor
    )

    val rng = Random(winner.index * 997 + 17)
    val bursts = listOf(
        // Main center royal burst over the Ludo goal
        Triple(0.50f, 0.44f, 0.00f),
        // Left & right flank bursts
        Triple(0.24f, 0.36f, 0.24f),
        Triple(0.76f, 0.36f, 0.34f),
        // Top celebratory crown shower
        Triple(0.50f, 0.22f, 0.62f)
    )

    return buildList {
        bursts.forEachIndexed { burstIdx, (ox, oy, delaySec) ->
            val count = if (burstIdx == 0) 54 else 32
            repeat(count) { i ->
                val angle = rng.nextFloat() * (2f * PI.toFloat())
                val speed = if (burstIdx == 0) {
                    0.35f + rng.nextFloat() * 0.78f
                } else {
                    0.28f + rng.nextFloat() * 0.62f
                }
                val shape = when {
                    i % 5 == 0 -> ParticleShape.STAR
                    i % 3 == 0 -> ParticleShape.SPARK
                    else -> ParticleShape.CONFETTI
                }
                val color = if (shape == ParticleShape.STAR) {
                    if (rng.nextBoolean()) RoyalGold else winner.lightColor
                } else {
                    palette[rng.nextInt(palette.size)]
                }

                add(
                    CelebrationParticle(
                        originNormX = ox + (rng.nextFloat() - 0.5f) * 0.04f,
                        originNormY = oy + (rng.nextFloat() - 0.5f) * 0.04f,
                        vxNorm = cos(angle) * speed,
                        vyNorm = sin(angle) * speed - 0.34f,
                        gravityNorm = 0.72f + rng.nextFloat() * 0.32f,
                        drag = 1.6f + rng.nextFloat() * 1.1f,
                        sizeDp = 7.5f + rng.nextFloat() * 6.5f,
                        color = color,
                        shape = shape,
                        startDelaySec = delaySec + rng.nextFloat() * 0.08f,
                        lifetimeSec = 2.1f + rng.nextFloat() * 0.9f,
                        initialRotationDeg = rng.nextFloat() * 360f,
                        angularVelDeg = (rng.nextFloat() - 0.5f) * 420f,
                        tumblePhase = rng.nextFloat() * (2f * PI.toFloat()),
                        tumbleSpeed = 6f + rng.nextFloat() * 8f
                    )
                )
            }
        }
    }
}

private fun DrawScope.drawCelebrationStar(
    center: Offset,
    outerRadius: Float,
    color: Color
) {
    val innerRadius = outerRadius * 0.45f
    val path = Path()
    for (i in 0 until 10) {
        val angle = -PI / 2.0 + i * (PI / 5.0)
        val r = if (i % 2 == 0) outerRadius else innerRadius
        val px = center.x + (cos(angle) * r).toFloat()
        val py = center.y + (sin(angle) * r).toFloat()
        if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
    }
    path.close()
    drawPath(path = path, color = color)
}
