package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Diamond
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Pets
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.SmartToy
import androidx.compose.material.icons.rounded.WorkspacePremium
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.game.HintType
import com.example.game.LudoBoardGeometry
import com.example.game.LudoUiState
import com.example.game.PlayerAvatar
import com.example.game.PlayerColor
import com.example.game.PlayerIdentity
import com.example.game.SeatControl
import com.example.game.toBengaliDigits
import com.example.ui.theme.DiceFaceBottom
import com.example.ui.theme.DiceFaceTop
import com.example.ui.theme.DiceLipShadow
import com.example.ui.theme.DicePipColor
import com.example.ui.theme.RoyalGold
import com.example.ui.theme.RoyalNavyBorder
import com.example.ui.theme.RoyalNavyPanelBottom
import com.example.ui.theme.RoyalNavyPanelTop
import com.example.ui.theme.RoyalTextMuted
import com.example.ui.theme.RoyalTextPrimary
import com.example.ui.theme.RoyalTextSecondary

@Composable
fun PlayerHudRow(
    uiState: LudoUiState,
    onPlayerClick: (PlayerColor) -> Unit = {},
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        PlayerColor.entries.forEach { player ->
            val seat = uiState.seats[player] ?: SeatControl.OFF
            val isActive = uiState.currentTurn == player && uiState.winner == null
            val isWinner = uiState.winner == player
            val finishedCount = uiState.pieces[player].orEmpty().count { it == LudoBoardGeometry.GOAL_PROGRESS }
            val identity = uiState.identities[player]
            val avatar = identity?.avatar ?: PlayerAvatar.defaultForColor(player)
            val name = playerDisplayName(player, uiState.identities)

            val borderColor = when {
                isWinner || isActive -> RoyalGold
                else -> Color.White.copy(alpha = 0.14f)
            }
            val bgColor = when {
                isWinner || isActive -> RoyalGold.copy(alpha = 0.15f)
                else -> Color.White.copy(alpha = 0.04f)
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .weight(1f)
                    .alpha(if (seat == SeatControl.OFF) 0.42f else 1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(bgColor)
                    .border(
                        width = if (isActive || isWinner) 1.8.dp else 1.dp,
                        color = borderColor,
                        shape = RoundedCornerShape(12.dp)
                    )
                    .clickable(role = Role.Button) { onPlayerClick(player) }
                    .padding(vertical = 6.dp, horizontal = 4.dp)
                    .testTag("player_card_${player.name.lowercase()}")
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(22.dp)
                        .clip(CircleShape)
                        .background(player.baseColor)
                        .border(1.2.dp, Color.White.copy(alpha = 0.85f), CircleShape)
                ) {
                    Icon(
                        imageVector = avatarIcon(avatar),
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                }
                Spacer(Modifier.height(3.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = name,
                        style = MaterialTheme.typography.labelMedium,
                        color = RoyalTextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (seat == SeatControl.BOT) {
                        Spacer(Modifier.width(2.dp))
                        Icon(
                            imageVector = Icons.Rounded.SmartToy,
                            contentDescription = stringResource(R.string.seat_bot),
                            tint = RoyalGold,
                            modifier = Modifier.size(11.dp)
                        )
                    } else if (seat == SeatControl.HUMAN) {
                        Spacer(Modifier.width(2.dp))
                        Icon(
                            imageVector = Icons.Rounded.Person,
                            contentDescription = stringResource(R.string.seat_human),
                            tint = RoyalTextSecondary,
                            modifier = Modifier.size(11.dp)
                        )
                    }
                }
                Spacer(Modifier.height(1.dp))
                Text(
                    text = if (seat == SeatControl.OFF) {
                        stringResource(R.string.seat_off)
                    } else {
                        "${finishedCount.toBengaliDigits()}/৪"
                    },
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = if (isActive || isWinner) RoyalGold else RoyalTextPrimary
                )
            }
        }
    }
}

@Composable
fun TurnControlBar(
    uiState: LudoUiState,
    onRollDice: () -> Unit,
    modifier: Modifier = Modifier
) {
    val focusPlayer = uiState.winner ?: uiState.currentTurn
    val activePlayerName = playerDisplayName(uiState.currentTurn, uiState.identities)
    val winnerName = uiState.winner?.let { playerDisplayName(it, uiState.identities) }
    val focusAvatar = uiState.identities[focusPlayer]?.avatar ?: PlayerAvatar.defaultForColor(focusPlayer)
    val isBotTurn = uiState.seats[uiState.currentTurn] == SeatControl.BOT

    val turnTitle = when {
        winnerName != null -> stringResource(R.string.winner_label, winnerName)
        isBotTurn -> stringResource(R.string.turn_bot_label, activePlayerName)
        else -> stringResource(R.string.turn_label, activePlayerName)
    }

    val hintText = when (uiState.hintType) {
        HintType.ROLL_DICE -> stringResource(R.string.hint_roll_dice)
        HintType.SELECT_TOKEN -> stringResource(R.string.hint_select_token)
        HintType.NO_MOVES -> stringResource(R.string.hint_no_moves)
        HintType.TOKEN_RELEASED -> stringResource(R.string.hint_token_released)
        HintType.TOKEN_MOVED -> stringResource(R.string.hint_token_moved)
        HintType.TOKEN_BONUS_SIX -> stringResource(R.string.hint_token_bonus_six)
        HintType.TOKEN_CAPTURED -> stringResource(R.string.hint_token_captured)
        HintType.TOKEN_HOME -> stringResource(R.string.hint_token_home)
        HintType.VICTORY -> stringResource(R.string.hint_victory, winnerName ?: activePlayerName)
        HintType.NEW_GAME -> stringResource(R.string.hint_new_game)
        HintType.BOT_THINKING -> stringResource(R.string.hint_bot_thinking)
    }

    val canHumanRoll = !uiState.hasRolled &&
        !uiState.isRollingDice &&
        uiState.winner == null &&
        uiState.seats[uiState.currentTurn] == SeatControl.HUMAN

    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(RoyalNavyPanelTop, RoyalNavyPanelBottom)
                )
            )
            .border(1.dp, RoyalNavyBorder, RoundedCornerShape(16.dp))
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(22.dp)
                        .clip(CircleShape)
                        .background(focusPlayer.baseColor)
                        .border(1.5.dp, Color.White, CircleShape)
                ) {
                    Icon(
                        imageVector = avatarIcon(focusAvatar),
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(13.dp)
                    )
                }
                Spacer(Modifier.width(8.dp))
                Text(
                    text = turnTitle,
                    style = MaterialTheme.typography.titleMedium,
                    color = if (uiState.winner != null) RoyalGold else RoyalTextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.height(3.dp))
            Text(
                text = hintText,
                style = MaterialTheme.typography.bodyMedium,
                color = if (uiState.hintType == HintType.SELECT_TOKEN) RoyalGold else RoyalTextSecondary
            )
        }

        Tactile3DDiceButton(
            diceValue = uiState.diceValue,
            isRolling = uiState.isRollingDice,
            isReadyToRoll = canHumanRoll,
            accentColor = uiState.currentTurn.baseColor,
            onClick = onRollDice
        )
    }
}

@Composable
fun Tactile3DDiceButton(
    diceValue: Int,
    isRolling: Boolean,
    isReadyToRoll: Boolean,
    accentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val infiniteTransition = rememberInfiniteTransition(label = "dice_ready_glow")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.78f,
        animationSpec = infiniteRepeatable(
            animation = tween(700),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow_alpha"
    )
    val rollRotation by infiniteTransition.animateFloat(
        initialValue = -10f,
        targetValue = 10f,
        animationSpec = infiniteRepeatable(
            animation = tween(90),
            repeatMode = RepeatMode.Reverse
        ),
        label = "roll_shake"
    )

    val pressOffset by animateDpAsState(
        targetValue = if (isPressed && isReadyToRoll) 4.dp else 0.dp,
        animationSpec = tween(70),
        label = "dice_press"
    )

    val diceCd = stringResource(R.string.cd_roll_dice, diceValue)

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .minimumInteractiveComponentSize()
            .size(68.dp)
            .testTag("roll_dice_button")
            .semantics { contentDescription = diceCd }
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                enabled = isReadyToRoll,
                role = Role.Button
            ) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            }
    ) {
        if (isReadyToRoll) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(18.dp))
                    .border(2.5.dp, RoyalGold.copy(alpha = glowAlpha), RoundedCornerShape(18.dp))
            )
        }

        // 3D bottom lip
        Box(
            modifier = Modifier
                .padding(horizontal = 4.dp, vertical = 2.dp)
                .size(58.dp)
                .offset(y = 4.dp)
                .clip(RoundedCornerShape(15.dp))
                .background(DiceLipShadow)
        )

        // Tactile 3D dice face
        Box(
            modifier = Modifier
                .size(58.dp)
                .offset(y = pressOffset)
                .rotate(if (isRolling) rollRotation else 0f)
                .shadow(6.dp, RoundedCornerShape(15.dp))
                .clip(RoundedCornerShape(15.dp))
                .background(
                    Brush.linearGradient(
                        colors = listOf(DiceFaceTop, DiceFaceBottom)
                    )
                )
                .border(
                    width = 1.5.dp,
                    color = if (isReadyToRoll) accentColor.copy(alpha = 0.7f) else RoyalTextMuted.copy(alpha = 0.4f),
                    shape = RoundedCornerShape(15.dp)
                )
        ) {
            Canvas(modifier = Modifier.fillMaxSize().padding(11.dp)) {
                val w = size.width
                val h = size.height
                val pipR = (w * 0.115f).coerceAtLeast(3.5f)
                val pipColor = if (diceValue == 6) accentColor else DicePipColor

                val tl = Offset(w * 0.18f, h * 0.18f)
                val tr = Offset(w * 0.82f, h * 0.18f)
                val ml = Offset(w * 0.18f, h * 0.50f)
                val cc = Offset(w * 0.50f, h * 0.50f)
                val mr = Offset(w * 0.82f, h * 0.50f)
                val bl = Offset(w * 0.18f, h * 0.82f)
                val br = Offset(w * 0.82f, h * 0.82f)

                val pips = when (diceValue) {
                    1 -> listOf(cc)
                    2 -> listOf(tl, br)
                    3 -> listOf(tl, cc, br)
                    4 -> listOf(tl, tr, bl, br)
                    5 -> listOf(tl, tr, cc, bl, br)
                    else -> listOf(tl, tr, ml, mr, bl, br)
                }

                pips.forEach { pos ->
                    drawCircle(
                        color = pipColor,
                        radius = pipR,
                        center = pos
                    )
                }
            }
        }
    }
}

@Composable
fun playerDisplayName(
    player: PlayerColor,
    identities: Map<PlayerColor, PlayerIdentity> = emptyMap()
): String {
    val custom = identities[player]?.nickname?.trim().orEmpty()
    if (custom.isNotEmpty()) return custom
    return when (player) {
        PlayerColor.RED -> stringResource(R.string.player_red)
        PlayerColor.BLUE -> stringResource(R.string.player_blue)
        PlayerColor.YELLOW -> stringResource(R.string.player_yellow)
        PlayerColor.GREEN -> stringResource(R.string.player_green)
    }
}

fun avatarIcon(avatar: PlayerAvatar) = when (avatar) {
    PlayerAvatar.CROWN -> Icons.Rounded.WorkspacePremium
    PlayerAvatar.SHIELD -> Icons.Rounded.Shield
    PlayerAvatar.DIAMOND -> Icons.Rounded.Diamond
    PlayerAvatar.TIGER -> Icons.Rounded.Pets
    PlayerAvatar.STAR -> Icons.Rounded.AutoAwesome
    PlayerAvatar.BOLT -> Icons.Rounded.Bolt
    PlayerAvatar.FLAME -> Icons.Rounded.LocalFireDepartment
    PlayerAvatar.TROPHY -> Icons.Rounded.EmojiEvents
}

@Composable
fun avatarLabel(avatar: PlayerAvatar): String = when (avatar) {
    PlayerAvatar.CROWN -> stringResource(R.string.avatar_crown)
    PlayerAvatar.SHIELD -> stringResource(R.string.avatar_shield)
    PlayerAvatar.DIAMOND -> stringResource(R.string.avatar_diamond)
    PlayerAvatar.TIGER -> stringResource(R.string.avatar_tiger)
    PlayerAvatar.STAR -> stringResource(R.string.avatar_star)
    PlayerAvatar.BOLT -> stringResource(R.string.avatar_bolt)
    PlayerAvatar.FLAME -> stringResource(R.string.avatar_flame)
    PlayerAvatar.TROPHY -> stringResource(R.string.avatar_trophy)
}
