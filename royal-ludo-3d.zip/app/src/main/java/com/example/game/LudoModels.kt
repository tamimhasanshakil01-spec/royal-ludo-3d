package com.example.game

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.LudoBlueBase
import com.example.ui.theme.LudoBlueDark
import com.example.ui.theme.LudoBlueLight
import com.example.ui.theme.LudoGreenBase
import com.example.ui.theme.LudoGreenDark
import com.example.ui.theme.LudoGreenLight
import com.example.ui.theme.LudoRedBase
import com.example.ui.theme.LudoRedDark
import com.example.ui.theme.LudoRedLight
import com.example.ui.theme.LudoYellowBase
import com.example.ui.theme.LudoYellowDark
import com.example.ui.theme.LudoYellowLight

data class BoardCoord(val row: Int, val col: Int)

enum class PlayerColor(
    val index: Int,
    val startTrackIndex: Int,
    val baseColor: Color,
    val lightColor: Color,
    val darkColor: Color,
    val homeTopLeft: BoardCoord
) {
    RED(
        index = 0,
        startTrackIndex = 0,
        baseColor = LudoRedBase,
        lightColor = LudoRedLight,
        darkColor = LudoRedDark,
        homeTopLeft = BoardCoord(0, 0)
    ),
    BLUE(
        index = 1,
        startTrackIndex = 13,
        baseColor = LudoBlueBase,
        lightColor = LudoBlueLight,
        darkColor = LudoBlueDark,
        homeTopLeft = BoardCoord(0, 9)
    ),
    YELLOW(
        index = 2,
        startTrackIndex = 26,
        baseColor = LudoYellowBase,
        lightColor = LudoYellowLight,
        darkColor = LudoYellowDark,
        homeTopLeft = BoardCoord(9, 9)
    ),
    GREEN(
        index = 3,
        startTrackIndex = 39,
        baseColor = LudoGreenBase,
        lightColor = LudoGreenLight,
        darkColor = LudoGreenDark,
        homeTopLeft = BoardCoord(9, 0)
    )
}

enum class SeatControl {
    HUMAN,
    BOT,
    OFF
}

enum class GamePreset {
    PASS_AND_PLAY,
    VS_BOTS,
    DUEL
}

enum class HintType {
    ROLL_DICE,
    SELECT_TOKEN,
    NO_MOVES,
    TOKEN_RELEASED,
    TOKEN_MOVED,
    TOKEN_BONUS_SIX,
    TOKEN_CAPTURED,
    TOKEN_HOME,
    VICTORY,
    NEW_GAME,
    BOT_THINKING
}

object LudoBoardGeometry {
    const val GRID_SIZE = 15
    const val HOME_YARD = -1
    const val MAX_OUTER_PROGRESS = 50
    const val GOAL_PROGRESS = 56

    // Exact 52-cell outer clockwise loop in a 15x15 Ludo grid
    val outerTrack: List<BoardCoord> = listOf(
        BoardCoord(6, 1), BoardCoord(6, 2), BoardCoord(6, 3), BoardCoord(6, 4), BoardCoord(6, 5),
        BoardCoord(5, 6), BoardCoord(4, 6), BoardCoord(3, 6), BoardCoord(2, 6), BoardCoord(1, 6), BoardCoord(0, 6),
        BoardCoord(0, 7), BoardCoord(0, 8),
        BoardCoord(1, 8), BoardCoord(2, 8), BoardCoord(3, 8), BoardCoord(4, 8), BoardCoord(5, 8),
        BoardCoord(6, 9), BoardCoord(6, 10), BoardCoord(6, 11), BoardCoord(6, 12), BoardCoord(6, 13), BoardCoord(6, 14),
        BoardCoord(7, 14), BoardCoord(8, 14),
        BoardCoord(8, 13), BoardCoord(8, 12), BoardCoord(8, 11), BoardCoord(8, 10), BoardCoord(8, 9),
        BoardCoord(9, 8), BoardCoord(10, 8), BoardCoord(11, 8), BoardCoord(12, 8), BoardCoord(13, 8), BoardCoord(14, 8),
        BoardCoord(14, 7), BoardCoord(14, 6),
        BoardCoord(13, 6), BoardCoord(12, 6), BoardCoord(11, 6), BoardCoord(10, 6), BoardCoord(9, 6),
        BoardCoord(8, 5), BoardCoord(8, 4), BoardCoord(8, 3), BoardCoord(8, 2), BoardCoord(8, 1), BoardCoord(8, 0),
        BoardCoord(7, 0), BoardCoord(6, 0)
    )

    val safeTrackIndices: Set<Int> = setOf(0, 8, 13, 21, 26, 34, 39, 47)
    val starTrackIndices: Set<Int> = setOf(8, 21, 34, 47)

    val homeStretches: Map<PlayerColor, List<BoardCoord>> = mapOf(
        PlayerColor.RED to listOf(
            BoardCoord(7, 1), BoardCoord(7, 2), BoardCoord(7, 3), BoardCoord(7, 4), BoardCoord(7, 5)
        ),
        PlayerColor.BLUE to listOf(
            BoardCoord(1, 7), BoardCoord(2, 7), BoardCoord(3, 7), BoardCoord(4, 7), BoardCoord(5, 7)
        ),
        PlayerColor.YELLOW to listOf(
            BoardCoord(7, 13), BoardCoord(7, 12), BoardCoord(7, 11), BoardCoord(7, 10), BoardCoord(7, 9)
        ),
        PlayerColor.GREEN to listOf(
            BoardCoord(13, 7), BoardCoord(12, 7), BoardCoord(11, 7), BoardCoord(10, 7), BoardCoord(9, 7)
        )
    )

    fun absoluteTrackIndex(player: PlayerColor, progress: Int): Int? {
        if (progress !in 0..MAX_OUTER_PROGRESS) return null
        return (player.startTrackIndex + progress) % outerTrack.size
    }

    fun coordForProgress(player: PlayerColor, progress: Int): BoardCoord? {
        return when {
            progress in 0..MAX_OUTER_PROGRESS -> outerTrack[absoluteTrackIndex(player, progress)!!]
            progress in 51..55 -> homeStretches[player]?.getOrNull(progress - 51)
            else -> null
        }
    }

    fun goalCoord(player: PlayerColor): Pair<Float, Float> {
        // Normalized fractional grid position inside center 3x3 (6..9, 6..9)
        return when (player) {
            PlayerColor.RED -> 6.62f to 7.50f
            PlayerColor.BLUE -> 7.50f to 6.62f
            PlayerColor.YELLOW -> 8.38f to 7.50f
            PlayerColor.GREEN -> 7.50f to 8.38f
        }
    }

    fun startArrowPlayer(trackIndex: Int): PlayerColor? {
        return PlayerColor.entries.firstOrNull { it.startTrackIndex == trackIndex }
    }

    fun homeStretchPlayer(coord: BoardCoord): PlayerColor? {
        return homeStretches.entries.firstOrNull { (_, list) -> coord in list }?.key
    }
}

data class TokenRenderPos(
    val player: PlayerColor,
    val tokenIndex: Int,
    val progress: Int,
    val isMovable: Boolean
)

data class LudoUiState(
    val seats: Map<PlayerColor, SeatControl> = mapOf(
        PlayerColor.RED to SeatControl.HUMAN,
        PlayerColor.BLUE to SeatControl.HUMAN,
        PlayerColor.YELLOW to SeatControl.HUMAN,
        PlayerColor.GREEN to SeatControl.HUMAN
    ),
    val pieces: Map<PlayerColor, List<Int>> = PlayerColor.entries.associateWith {
        listOf(-1, -1, -1, -1)
    },
    val currentTurn: PlayerColor = PlayerColor.RED,
    val diceValue: Int = 1,
    val isRollingDice: Boolean = false,
    val hasRolled: Boolean = false,
    val movableTokenIndices: Set<Int> = emptySet(),
    val winner: PlayerColor? = null,
    val hintType: HintType = HintType.ROLL_DICE,
    val activePreset: GamePreset = GamePreset.PASS_AND_PLAY,
    val referralCode: String = "ROYAL-0000",
    val invitedSignups: Int = 0,
    val approvedRewardBdt: Int = 0,
    val totalGamesPlayed: Int = 0,
    val totalWins: Int = 0,
    val isSoundEnabled: Boolean = true,
    val identities: Map<PlayerColor, PlayerIdentity> = defaultIdentities()
)

enum class PlayerAvatar(val defaultFor: PlayerColor?) {
    CROWN(PlayerColor.RED),
    SHIELD(PlayerColor.BLUE),
    DIAMOND(PlayerColor.YELLOW),
    TIGER(PlayerColor.GREEN),
    STAR(null),
    BOLT(null),
    FLAME(null),
    TROPHY(null);

    companion object {
        fun defaultForColor(color: PlayerColor): PlayerAvatar {
            return entries.firstOrNull { it.defaultFor == color } ?: CROWN
        }

        fun fromStorage(raw: String?, fallbackColor: PlayerColor): PlayerAvatar {
            return entries.firstOrNull { it.name == raw } ?: defaultForColor(fallbackColor)
        }
    }
}

data class PlayerIdentity(
    val nickname: String = "",
    val avatar: PlayerAvatar = PlayerAvatar.CROWN
)

fun defaultIdentities(): Map<PlayerColor, PlayerIdentity> {
    return PlayerColor.entries.associateWith { color ->
        PlayerIdentity(
            nickname = "",
            avatar = PlayerAvatar.defaultForColor(color)
        )
    }
}

fun Int.toBengaliDigits(): String {
    val bengaliDigits = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')
    return this.toString().map { ch ->
        if (ch in '0'..'9') bengaliDigits[ch - '0'] else ch
    }.joinToString("")
}
