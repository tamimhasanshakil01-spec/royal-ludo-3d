package com.example.game

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.random.Random

class LudoViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val soundManager: GameSoundPlayer = LudoSoundManager(application)
    private val _uiState = MutableStateFlow(loadInitialState())
    val uiState: StateFlow<LudoUiState> = _uiState.asStateFlow()

    private var turnJob: Job? = null

    private fun loadInitialState(): LudoUiState {
        val savedCode = prefs.getString(KEY_REFERRAL_CODE, null) ?: run {
            val generated = "ROYAL-" + buildString {
                val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
                repeat(5) { append(chars[Random.nextInt(chars.length)]) }
            }
            prefs.edit().putString(KEY_REFERRAL_CODE, generated).apply()
            generated
        }
        val gamesPlayed = prefs.getInt(KEY_GAMES_PLAYED, 0)
        val totalWins = prefs.getInt(KEY_TOTAL_WINS, 0)
        val soundEnabled = prefs.getBoolean(KEY_SOUND_ENABLED, true)
        soundManager.setEnabled(soundEnabled)
        val savedIdentities = PlayerColor.entries.associateWith { color ->
            val nick = prefs.getString(nicknameKey(color), "") ?: ""
            val avatarRaw = prefs.getString(avatarKey(color), null)
            PlayerIdentity(
                nickname = nick,
                avatar = PlayerAvatar.fromStorage(avatarRaw, color)
            )
        }
        return LudoUiState(
            referralCode = savedCode,
            totalGamesPlayed = gamesPlayed,
            totalWins = totalWins,
            isSoundEnabled = soundEnabled,
            identities = savedIdentities
        )
    }

    fun updateAllIdentities(updated: Map<PlayerColor, PlayerIdentity>) {
        val sanitized = PlayerColor.entries.associateWith { color ->
            val raw = updated[color] ?: PlayerIdentity(avatar = PlayerAvatar.defaultForColor(color))
            raw.copy(nickname = raw.nickname.trim().take(MAX_NICKNAME_LENGTH))
        }
        prefs.edit().apply {
            sanitized.forEach { (color, id) ->
                putString(nicknameKey(color), id.nickname)
                putString(avatarKey(color), id.avatar.name)
            }
        }.apply()
        _uiState.update { it.copy(identities = sanitized) }
    }

    fun resetIdentities() {
        val defaults = defaultIdentities()
        updateAllIdentities(defaults)
    }

    fun toggleSound() {
        val next = !_uiState.value.isSoundEnabled
        soundManager.setEnabled(next)
        prefs.edit().putBoolean(KEY_SOUND_ENABLED, next).apply()
        _uiState.update { it.copy(isSoundEnabled = next) }
    }

    fun startNewGame(seats: Map<PlayerColor, SeatControl>, preset: GamePreset = detectPreset(seats)) {
        turnJob?.cancel()
        val activePlayers = PlayerColor.entries.filter { seats[it] != SeatControl.OFF }
        val firstTurn = activePlayers.firstOrNull() ?: PlayerColor.RED
        val sanitizedSeats = if (activePlayers.size >= 2) {
            seats
        } else {
            mapOf(
                PlayerColor.RED to SeatControl.HUMAN,
                PlayerColor.BLUE to SeatControl.HUMAN,
                PlayerColor.YELLOW to SeatControl.HUMAN,
                PlayerColor.GREEN to SeatControl.HUMAN
            )
        }

        _uiState.update { state ->
            state.copy(
                seats = sanitizedSeats,
                pieces = PlayerColor.entries.associateWith { player ->
                    if (sanitizedSeats[player] == SeatControl.OFF) {
                        emptyList()
                    } else {
                        listOf(-1, -1, -1, -1)
                    }
                },
                currentTurn = firstTurn,
                diceValue = 1,
                isRollingDice = false,
                hasRolled = false,
                movableTokenIndices = emptySet(),
                winner = null,
                hintType = if (sanitizedSeats[firstTurn] == SeatControl.BOT) HintType.BOT_THINKING else HintType.ROLL_DICE,
                activePreset = preset
            )
        }
        maybeScheduleBotTurn()
    }

    fun applyPreset(preset: GamePreset) {
        val seats = when (preset) {
            GamePreset.PASS_AND_PLAY -> mapOf(
                PlayerColor.RED to SeatControl.HUMAN,
                PlayerColor.BLUE to SeatControl.HUMAN,
                PlayerColor.YELLOW to SeatControl.HUMAN,
                PlayerColor.GREEN to SeatControl.HUMAN
            )
            GamePreset.VS_BOTS -> mapOf(
                PlayerColor.RED to SeatControl.HUMAN,
                PlayerColor.BLUE to SeatControl.BOT,
                PlayerColor.YELLOW to SeatControl.BOT,
                PlayerColor.GREEN to SeatControl.BOT
            )
            GamePreset.DUEL -> mapOf(
                PlayerColor.RED to SeatControl.HUMAN,
                PlayerColor.BLUE to SeatControl.OFF,
                PlayerColor.YELLOW to SeatControl.HUMAN,
                PlayerColor.GREEN to SeatControl.OFF
            )
        }
        startNewGame(seats, preset)
    }

    fun resetCurrentGame() {
        startNewGame(_uiState.value.seats, _uiState.value.activePreset)
    }

    fun rollDice() {
        val current = _uiState.value
        if (current.hasRolled || current.isRollingDice || current.winner != null) return
        if (current.seats[current.currentTurn] == SeatControl.BOT) return
        performDiceRoll()
    }

    private fun performDiceRoll() {
        turnJob?.cancel()
        turnJob = viewModelScope.launch {
            soundManager.playDiceRoll()
            _uiState.update { it.copy(isRollingDice = true) }
            repeat(6) {
                _uiState.update { it.copy(diceValue = Random.nextInt(1, 7)) }
                delay(55)
            }
            val rolled = Random.nextInt(1, 7)
            val stateBeforeMove = _uiState.value
            val turnPlayer = stateBeforeMove.currentTurn
            val playerPieces = stateBeforeMove.pieces[turnPlayer].orEmpty()
            val validIndices = computeMovableIndices(playerPieces, rolled)

            if (validIndices.isEmpty()) {
                _uiState.update {
                    it.copy(
                        diceValue = rolled,
                        isRollingDice = false,
                        hasRolled = true,
                        movableTokenIndices = emptySet(),
                        hintType = HintType.NO_MOVES
                    )
                }
                delay(if (rolled == 6) 750L else 600L)
                advanceToNextTurn()
            } else {
                val isBot = stateBeforeMove.seats[turnPlayer] == SeatControl.BOT
                _uiState.update {
                    it.copy(
                        diceValue = rolled,
                        isRollingDice = false,
                        hasRolled = true,
                        movableTokenIndices = validIndices,
                        hintType = if (isBot) HintType.BOT_THINKING else HintType.SELECT_TOKEN
                    )
                }
                if (isBot) {
                    delay(450L)
                    val chosenIndex = chooseBotToken(turnPlayer, validIndices, rolled, _uiState.value)
                    executeMove(turnPlayer, chosenIndex)
                }
            }
        }
    }

    fun moveToken(player: PlayerColor, tokenIndex: Int) {
        val current = _uiState.value
        if (player != current.currentTurn || !current.hasRolled || current.isRollingDice || current.winner != null) return
        if (current.seats[player] == SeatControl.BOT) return
        if (tokenIndex !in current.movableTokenIndices) return
        executeMove(player, tokenIndex)
    }

    private fun executeMove(player: PlayerColor, tokenIndex: Int) {
        val state = _uiState.value
        val dice = state.diceValue
        val currentPieces = state.pieces[player]?.toMutableList() ?: return
        val oldProgress = currentPieces.getOrNull(tokenIndex) ?: return

        val newProgress = if (oldProgress == LudoBoardGeometry.HOME_YARD) {
            if (dice == 6) 0 else return
        } else {
            val candidate = oldProgress + dice
            if (candidate > LudoBoardGeometry.GOAL_PROGRESS) return
            candidate
        }

        currentPieces[tokenIndex] = newProgress
        val updatedAllPieces = state.pieces.toMutableMap()
        updatedAllPieces[player] = currentPieces

        var capturedAny = false
        val newAbsIndex = LudoBoardGeometry.absoluteTrackIndex(player, newProgress)
        if (newAbsIndex != null && newAbsIndex !in LudoBoardGeometry.safeTrackIndices) {
            for (other in PlayerColor.entries) {
                if (other == player) continue
                val otherList = updatedAllPieces[other]?.toMutableList() ?: continue
                var modified = false
                for (j in otherList.indices) {
                    val otherAbs = LudoBoardGeometry.absoluteTrackIndex(other, otherList[j])
                    if (otherAbs == newAbsIndex) {
                        otherList[j] = LudoBoardGeometry.HOME_YARD
                        modified = true
                        capturedAny = true
                    }
                }
                if (modified) {
                    updatedAllPieces[other] = otherList
                }
            }
        }

        val hasWon = currentPieces.isNotEmpty() && currentPieces.all { it == LudoBoardGeometry.GOAL_PROGRESS }
        val reachedHome = newProgress == LudoBoardGeometry.GOAL_PROGRESS
        val earnedBonusRoll = !hasWon && (dice == 6 || capturedAny || reachedHome)

        soundManager.playTokenMove()
        when {
            hasWon -> soundManager.playVictory()
            capturedAny -> soundManager.playTokenCapture()
            reachedHome -> soundManager.playTokenHome()
        }

        val nextHint = when {
            hasWon -> HintType.VICTORY
            capturedAny -> HintType.TOKEN_CAPTURED
            reachedHome -> HintType.TOKEN_HOME
            oldProgress == LudoBoardGeometry.HOME_YARD -> HintType.TOKEN_RELEASED
            dice == 6 -> HintType.TOKEN_BONUS_SIX
            else -> HintType.TOKEN_MOVED
        }

        var gamesPlayed = state.totalGamesPlayed
        var wins = state.totalWins
        if (hasWon) {
            gamesPlayed += 1
            if (state.seats[player] == SeatControl.HUMAN) {
                wins += 1
            }
            prefs.edit()
                .putInt(KEY_GAMES_PLAYED, gamesPlayed)
                .putInt(KEY_TOTAL_WINS, wins)
                .apply()
        }

        _uiState.update {
            it.copy(
                pieces = updatedAllPieces,
                winner = if (hasWon) player else null,
                hasRolled = false,
                movableTokenIndices = emptySet(),
                hintType = nextHint,
                totalGamesPlayed = gamesPlayed,
                totalWins = wins
            )
        }

        if (!hasWon) {
            if (earnedBonusRoll) {
                maybeScheduleBotTurn()
            } else {
                turnJob?.cancel()
                turnJob = viewModelScope.launch {
                    delay(420L)
                    advanceToNextTurn()
                }
            }
        }
    }

    private fun advanceToNextTurn() {
        val current = _uiState.value
        if (current.winner != null) return
        val activeOrder = PlayerColor.entries.filter { current.seats[it] != SeatControl.OFF }
        if (activeOrder.isEmpty()) return
        val idx = activeOrder.indexOf(current.currentTurn)
        val nextPlayer = activeOrder[(idx + 1) % activeOrder.size]
        val isBot = current.seats[nextPlayer] == SeatControl.BOT

        _uiState.update {
            it.copy(
                currentTurn = nextPlayer,
                hasRolled = false,
                isRollingDice = false,
                movableTokenIndices = emptySet(),
                hintType = if (isBot) HintType.BOT_THINKING else HintType.ROLL_DICE
            )
        }
        maybeScheduleBotTurn()
    }

    private fun maybeScheduleBotTurn() {
        val current = _uiState.value
        if (current.winner != null) return
        if (current.seats[current.currentTurn] == SeatControl.BOT) {
            turnJob?.cancel()
            turnJob = viewModelScope.launch {
                delay(480L)
                performDiceRoll()
            }
        }
    }

    private fun computeMovableIndices(pieces: List<Int>, dice: Int): Set<Int> {
        return pieces.indices.filter { idx ->
            val pos = pieces[idx]
            when {
                pos == LudoBoardGeometry.HOME_YARD -> dice == 6
                pos >= LudoBoardGeometry.GOAL_PROGRESS -> false
                else -> pos + dice <= LudoBoardGeometry.GOAL_PROGRESS
            }
        }.toSet()
    }

    private fun chooseBotToken(
        bot: PlayerColor,
        movableIndices: Set<Int>,
        dice: Int,
        state: LudoUiState
    ): Int {
        val botPieces = state.pieces[bot].orEmpty()
        return movableIndices.maxByOrNull { idx ->
            val currentPos = botPieces[idx]
            val targetPos = if (currentPos == LudoBoardGeometry.HOME_YARD) 0 else currentPos + dice
            var score = targetPos
            if (targetPos == LudoBoardGeometry.GOAL_PROGRESS) score += 1000
            val targetAbs = LudoBoardGeometry.absoluteTrackIndex(bot, targetPos)
            if (targetAbs != null) {
                if (targetAbs !in LudoBoardGeometry.safeTrackIndices) {
                    val canCapture = PlayerColor.entries.any { other ->
                        other != bot && state.pieces[other].orEmpty().any { otherPos ->
                            LudoBoardGeometry.absoluteTrackIndex(other, otherPos) == targetAbs
                        }
                    }
                    if (canCapture) score += 700
                } else {
                    score += 180
                }
            }
            if (currentPos == LudoBoardGeometry.HOME_YARD && dice == 6) score += 400
            if (targetPos in 51..55 && currentPos <= 50) score += 260
            score
        } ?: movableIndices.first()
    }

    private fun detectPreset(seats: Map<PlayerColor, SeatControl>): GamePreset {
        val active = seats.values.count { it != SeatControl.OFF }
        val bots = seats.values.count { it == SeatControl.BOT }
        return when {
            active == 2 -> GamePreset.DUEL
            bots > 0 -> GamePreset.VS_BOTS
            else -> GamePreset.PASS_AND_PLAY
        }
    }

    override fun onCleared() {
        turnJob?.cancel()
        soundManager.release()
        super.onCleared()
    }

    companion object {
        private const val PREFS_NAME = "royal_ludo_prefs"
        private const val KEY_REFERRAL_CODE = "referral_code"
        private const val KEY_GAMES_PLAYED = "games_played"
        private const val KEY_TOTAL_WINS = "total_wins"
        private const val KEY_SOUND_ENABLED = "sound_enabled"
        private const val MAX_NICKNAME_LENGTH = 16

        private fun nicknameKey(color: PlayerColor) = "nickname_${color.name}"
        private fun avatarKey(color: PlayerColor) = "avatar_${color.name}"
    }
}
