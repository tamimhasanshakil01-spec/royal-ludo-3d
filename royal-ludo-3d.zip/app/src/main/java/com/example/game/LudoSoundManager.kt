package com.example.game

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import com.example.R

interface GameSoundPlayer {
    fun setEnabled(enabled: Boolean)
    fun playDiceRoll()
    fun playTokenMove()
    fun playTokenCapture()
    fun playTokenHome()
    fun playVictory()
    fun release()
}

class LudoSoundManager(context: Context) : GameSoundPlayer {

    @Volatile
    private var enabled: Boolean = true

    private val loadedIds = mutableSetOf<Int>()
    private val soundPool: SoundPool?
    private val diceRollId: Int
    private val tokenMoveId: Int
    private val tokenCaptureId: Int
    private val tokenHomeId: Int
    private val victoryId: Int

    init {
        val attributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        val pool = try {
            SoundPool.Builder()
                .setMaxStreams(6)
                .setAudioAttributes(attributes)
                .build()
        } catch (_: Throwable) {
            null
        }

        soundPool = pool
        if (pool != null) {
            pool.setOnLoadCompleteListener { _, sampleId, status ->
                if (status == 0) {
                    synchronized(loadedIds) {
                        loadedIds.add(sampleId)
                    }
                }
            }
            val appCtx = context.applicationContext
            diceRollId = safeLoad(pool, appCtx, R.raw.dice_roll)
            tokenMoveId = safeLoad(pool, appCtx, R.raw.token_move)
            tokenCaptureId = safeLoad(pool, appCtx, R.raw.token_capture)
            tokenHomeId = safeLoad(pool, appCtx, R.raw.token_home)
            victoryId = safeLoad(pool, appCtx, R.raw.victory_fanfare)
        } else {
            diceRollId = 0
            tokenMoveId = 0
            tokenCaptureId = 0
            tokenHomeId = 0
            victoryId = 0
        }
    }

    private fun safeLoad(pool: SoundPool, context: Context, resId: Int): Int {
        return try {
            pool.load(context, resId, 1)
        } catch (_: Throwable) {
            0
        }
    }

    override fun setEnabled(enabled: Boolean) {
        this.enabled = enabled
    }

    override fun playDiceRoll() {
        playSample(diceRollId, volume = 0.85f, rate = 1.0f)
    }

    override fun playTokenMove() {
        playSample(tokenMoveId, volume = 0.90f, rate = 1.02f)
    }

    override fun playTokenCapture() {
        playSample(tokenCaptureId, volume = 1.0f, rate = 1.0f)
    }

    override fun playTokenHome() {
        playSample(tokenHomeId, volume = 0.95f, rate = 1.0f)
    }

    override fun playVictory() {
        playSample(victoryId, volume = 1.0f, rate = 1.0f)
    }

    private fun playSample(soundId: Int, volume: Float, rate: Float) {
        if (!enabled || soundId == 0) return
        val pool = soundPool ?: return
        val isReady = synchronized(loadedIds) { soundId in loadedIds }
        if (!isReady) return
        try {
            pool.play(soundId, volume, volume, 1, 0, rate)
        } catch (_: Throwable) {
            // Ignore audio playback errors on devices without audio output
        }
    }

    override fun release() {
        try {
            soundPool?.release()
        } catch (_: Throwable) {
            // Safe cleanup
        }
        synchronized(loadedIds) {
            loadedIds.clear()
        }
    }
}
