package com.example

import com.example.game.BoardCoord
import com.example.game.LudoBoardGeometry
import com.example.game.PlayerColor
import com.example.game.toBengaliDigits
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class LudoGeometryTest {
    @Test
    fun outerTrackHas52UniqueCells() {
        assertEquals(52, LudoBoardGeometry.outerTrack.size)
        assertEquals(52, LudoBoardGeometry.outerTrack.toSet().size)
    }

    @Test
    fun eachPlayerTurnsIntoHomeStretchAfter50Steps() {
        assertEquals(BoardCoord(7, 0), LudoBoardGeometry.coordForProgress(PlayerColor.RED, 50))
        assertEquals(BoardCoord(7, 1), LudoBoardGeometry.coordForProgress(PlayerColor.RED, 51))

        assertEquals(BoardCoord(0, 7), LudoBoardGeometry.coordForProgress(PlayerColor.BLUE, 50))
        assertEquals(BoardCoord(1, 7), LudoBoardGeometry.coordForProgress(PlayerColor.BLUE, 51))

        assertEquals(BoardCoord(7, 14), LudoBoardGeometry.coordForProgress(PlayerColor.YELLOW, 50))
        assertEquals(BoardCoord(7, 13), LudoBoardGeometry.coordForProgress(PlayerColor.YELLOW, 51))

        assertEquals(BoardCoord(14, 7), LudoBoardGeometry.coordForProgress(PlayerColor.GREEN, 50))
        assertEquals(BoardCoord(13, 7), LudoBoardGeometry.coordForProgress(PlayerColor.GREEN, 51))

        assertNull(LudoBoardGeometry.coordForProgress(PlayerColor.RED, 56))
    }

    @Test
    fun bengaliDigitsFormatCorrectly() {
        assertEquals("০", 0.toBengaliDigits())
        assertEquals("৪", 4.toBengaliDigits())
        assertEquals("১২৩", 123.toBengaliDigits())
    }
}
